#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
if [[ "$(uname -s)" != "Darwin" ]]; then echo "This installer runs on macOS only."; exit 1; fi
mkdir -p "$HOME/Downloads/AVERA-Offline-Licensing"
cp "$ROOT/AVERA-Offline-Licensing/avera_licenses.py" "$HOME/Downloads/AVERA-Offline-Licensing/avera_licenses.py"
if [[ ! -f "$HOME/.avera-license-manager/signing-public.pem" ]]; then
  echo "No signing key found. Initializing license keys..."
  python3 "$HOME/Downloads/AVERA-Offline-Licensing/avera_licenses.py" init
fi
printf '\n=== Building AVERA ===\n'
(cd "$ROOT/AVERA-App" && bash install.sh)
printf '\n=== Building Key Manager ===\n'
(cd "$ROOT/AVERA-Key-Manager-Mac" && bash install.sh)
printf '\nInstalled AVERA and AVERA Key Manager.\n'
