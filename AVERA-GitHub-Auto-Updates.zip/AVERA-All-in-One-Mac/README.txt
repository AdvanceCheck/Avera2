AVERA — Ollama Local AI Edition

Requires macOS, Swift command-line tools, Ollama and the gemma3:4b model.

SETUP
1. Install Ollama (if needed), then run: ollama pull gemma3:4b
2. Start the Ollama server: ollama serve
   (If Ollama is already running as an app, don't start a second server.)
3. In Terminal, from this folder run: bash install.sh
4. Sign in to AVERA using your existing local account.
5. For screen analysis, grant AVERA Screen Recording access in macOS Settings.

The app connects to http://127.0.0.1:11434/api/chat with model gemma3:4b.
Chat and screenshot analysis run on your Mac, with no per-request API charges.
Screen analysis is opt-in and analyzes locally every 15 seconds while enabled;
this can be demanding on memory/CPU. Turn it off when not needed.

Your existing account, saved chat data and licensing keys are not removed.
The installer keeps backups of the previous AVERA app.
The offline licensing script may require Python's cryptography package.

NOTE: Source updated but NOT compiled/tested on macOS in this environment.

Ollama auto-start: AVERA checks the local Ollama server on launch and starts it quietly if needed. Ollama must be installed and gemma3:4b downloaded. AVERA stops only the server process it started when it quits.
