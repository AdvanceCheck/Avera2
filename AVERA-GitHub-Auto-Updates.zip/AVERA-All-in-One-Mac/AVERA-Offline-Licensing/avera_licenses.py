#!/usr/bin/env python3
"""AVERA offline Ed25519 license issuer and verifier (Python 3.9+)."""
import argparse, base64, datetime as dt, json, os, pathlib, secrets, sys
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

HOME = pathlib.Path.home() / '.avera-license-manager'
PRIVATE = HOME / 'signing-private.pem'
PUBLIC = HOME / 'signing-public.pem'
RECORDS = HOME / 'issued.json'
UTC = dt.timezone.utc

def encoded(data): return base64.urlsafe_b64encode(data).decode().rstrip('=')
def decoded(data): return base64.urlsafe_b64decode(data + '=' * (-len(data) % 4))
def canonical(data): return json.dumps(data, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
def now(): return dt.datetime.now(UTC).isoformat(timespec='seconds')
def setup():
    HOME.mkdir(mode=0o700, parents=True, exist_ok=True)
    if PRIVATE.exists() or PUBLIC.exists():
        raise SystemExit('Signing keys already exist. Refusing to overwrite them.')
    private = Ed25519PrivateKey.generate()
    priv_bytes = private.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
    fd = os.open(PRIVATE, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as f: f.write(priv_bytes)
    PUBLIC.write_bytes(private.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo))
    RECORDS.write_text('[]\n')
    print('Signing keys created in:', HOME)
    print('Keep signing-private.pem SECRET. Back it up securely; never distribute it.')
    print('Distribute ONLY signing-public.pem with AVERA.')

def read_records():
    return json.loads(RECORDS.read_text()) if RECORDS.exists() else []
def save_records(records):
    temp = RECORDS.with_suffix('.tmp')
    temp.write_text(json.dumps(records, indent=2) + '\n')
    os.replace(temp, RECORDS)

def issue(customer, days, output):
    if not PRIVATE.exists(): raise SystemExit('Run init first.')
    private = serialization.load_pem_private_key(PRIVATE.read_bytes(), password=None)
    issued = dt.datetime.now(UTC)
    claims = {'v': 1, 'product': 'AVERA', 'license_id': secrets.token_hex(8).upper(),
              'customer': customer, 'issued_at': issued.isoformat(timespec='seconds'),
              'expires_at': (issued + dt.timedelta(days=days)).isoformat(timespec='seconds') if days else None}
    signature = private.sign(canonical(claims))
    token = 'AVERA1.' + encoded(canonical(claims)) + '.' + encoded(signature)
    record = {**claims, 'status_in_manager': 'issued'}
    records = read_records(); records.append(record); save_records(records)
    if output:
        pathlib.Path(output).write_text(token + '\n')
        print('License saved to:', output)
    print('License ID:', claims['license_id'])
    print('Customer:', customer)
    print('Expires:', claims['expires_at'] or 'Never')
    print('\nActivation key (copy the entire line):\n' + token)
    print('\nIMPORTANT: Offline revocation in this manager does NOT disable licenses already distributed.')

def verify(token, public_path):
    try:
        prefix, claims_b64, sig_b64 = token.strip().split('.')
        if prefix != 'AVERA1': raise ValueError('Unsupported key format')
        claims_bytes = decoded(claims_b64)
        claims = json.loads(claims_bytes)
        if canonical(claims) != claims_bytes: raise ValueError('Invalid claim encoding')
        public = serialization.load_pem_public_key(pathlib.Path(public_path).read_bytes())
        if not isinstance(public, Ed25519PublicKey): raise ValueError('Invalid public key')
        public.verify(decoded(sig_b64), claims_bytes)
        if claims.get('v') != 1 or claims.get('product') != 'AVERA': raise ValueError('Wrong product or version')
        expiry = claims.get('expires_at')
        if expiry and dt.datetime.now(UTC) >= dt.datetime.fromisoformat(expiry): raise ValueError('License expired')
        return claims
    except (ValueError, KeyError, TypeError, InvalidSignature, json.JSONDecodeError) as exc:
        raise ValueError('Invalid license: ' + str(exc)) from exc

def main():
    parser = argparse.ArgumentParser(description='AVERA offline license manager')
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('init', help='Generate signing keypair (once)')
    p = sub.add_parser('issue', help='Generate signed activation key')
    p.add_argument('--customer', required=True, help='Customer label/name')
    p.add_argument('--days', type=int, default=365, help='Validity in days; 0 means no expiry')
    p.add_argument('--output', help='Optional license text file')
    sub.add_parser('list', help='List issued licenses')
    p = sub.add_parser('delete', help='Delete one local license record (does not invalidate signed keys)')
    p.add_argument('license_id')
    sub.add_parser('delete-all', help='Delete all local license records (signing keys untouched)')
    p = sub.add_parser('revoke', help='Mark license revoked in local manager only')
    p.add_argument('license_id')
    p = sub.add_parser('verify', help='Verify a key using the public key')
    p.add_argument('--file', help='Read key from text file')
    p.add_argument('--key', help='Read key from command line (less private)')
    p.add_argument('--public', default=str(PUBLIC), help='Public key path')
    args = parser.parse_args()
    if args.command == 'init': setup()
    elif args.command == 'issue':
        if args.days < 0: parser.error('--days must be >= 0')
        issue(args.customer, args.days, args.output)
    elif args.command == 'list':
        for r in read_records():
            print(f"{r['license_id']} | {r['customer']} | {r['status_in_manager']} | expires {r['expires_at'] or 'never'}")
    elif args.command == 'delete':
        records = read_records()
        remaining = [r for r in records if r['license_id'] != args.license_id]
        if len(remaining) == len(records): raise SystemExit('License ID not found.')
        save_records(remaining)
        print('Deleted local record:', args.license_id)
        print('Already-distributed offline activation keys are NOT disabled.')
    elif args.command == 'delete-all':
        count = len(read_records())
        save_records([])
        print(f'Deleted {count} local license record(s).')
        print('Signing keys were NOT changed. Already-issued offline keys still work.')
    elif args.command == 'revoke':
        records = read_records()
        for r in records:
            if r['license_id'] == args.license_id:
                r['status_in_manager'] = 'revoked'; save_records(records)
                print('Marked revoked in local records. Already-issued offline keys STILL work until expiration.')
                return
        raise SystemExit('License ID not found.')
    elif args.command == 'verify':
        if not args.file and not args.key: parser.error('Specify --file or --key')
        token = pathlib.Path(args.file).read_text().strip() if args.file else args.key
        try: print('VALID:', json.dumps(verify(token, args.public), indent=2))
        except (ValueError, OSError) as exc: raise SystemExit(str(exc))

if __name__ == '__main__': main()
