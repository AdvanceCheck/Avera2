#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f "$HOME/Downloads/AVERA-Offline-Licensing/avera_licenses.py" ]; then
  echo "ERROR: Keep the AVERA-Offline-Licensing folder in Downloads."
  exit 1
fi
mkdir -p "$HOME/Applications/AVERA Key Manager.app/Contents/MacOS"
mkdir -p "$HOME/Applications/AVERA Key Manager.app/Contents/Resources"
swiftc -parse-as-library -O KeyManager.swift -o "$HOME/Applications/AVERA Key Manager.app/Contents/MacOS/AVERAKeyManager"
cat > "$HOME/Applications/AVERA Key Manager.app/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>AVERAKeyManager</string>
<key>CFBundleIdentifier</key><string>com.avera.keymanager</string>
<key>CFBundleName</key><string>AVERA Key Manager</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleVersion</key><string>1</string>
<key>LSMinimumSystemVersion</key><string>12.0</string>
<key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST
echo "Installed: $HOME/Applications/AVERA Key Manager.app"
open "$HOME/Applications/AVERA Key Manager.app"
