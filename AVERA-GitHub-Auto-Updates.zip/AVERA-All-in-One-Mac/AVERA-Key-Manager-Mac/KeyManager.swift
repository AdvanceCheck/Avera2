import AppKit
import Foundation
import QuartzCore

@MainActor final class GlowButton: NSButton {
    private var tracking: NSTrackingArea?
    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        if let tracking { removeTrackingArea(tracking) }
        let a = NSTrackingArea(rect: bounds, options: [.mouseEnteredAndExited, .activeInKeyWindow, .inVisibleRect], owner: self, userInfo: nil)
        addTrackingArea(a); tracking = a
    }
    override func mouseEntered(with event: NSEvent) { super.mouseEntered(with: event); animate(true) }
    override func mouseExited(with event: NSEvent) { super.mouseExited(with: event); animate(false) }
    private func animate(_ on: Bool) {
        wantsLayer = true
        let a = CABasicAnimation(keyPath: "backgroundColor")
        a.fromValue = layer?.backgroundColor
        a.toValue = NSColor.white.withAlphaComponent(on ? 0.18 : 0.07).cgColor
        a.duration = 0.22; layer?.add(a, forKey: "hover")
        layer?.backgroundColor = NSColor.white.withAlphaComponent(on ? 0.18 : 0.07).cgColor
        layer?.shadowColor = NSColor.white.cgColor
        layer?.shadowRadius = on ? 15 : 0
        layer?.shadowOpacity = on ? 0.24 : 0
    }
}

@MainActor final class StarView: NSView {
    private let star = CAShapeLayer()
    override init(frame: NSRect) {
        super.init(frame: frame); wantsLayer = true
        star.fillColor = NSColor.white.cgColor
        star.shadowColor = NSColor.white.cgColor
        star.shadowRadius = 16; star.shadowOpacity = 0.9; star.shadowOffset = .zero
        layer?.addSublayer(star)
        let spin = CABasicAnimation(keyPath: "transform.rotation.z")
        spin.fromValue = 0; spin.toValue = Double.pi * 2
        spin.duration = 16; spin.repeatCount = .infinity
        star.add(spin, forKey: "spin")
        let pulse = CABasicAnimation(keyPath: "shadowRadius")
        pulse.fromValue = 6; pulse.toValue = 22; pulse.duration = 2.2
        pulse.autoreverses = true; pulse.repeatCount = .infinity
        star.add(pulse, forKey: "pulse")
    }
    required init?(coder: NSCoder) { fatalError() }
    override func layout() {
        super.layout(); star.frame = bounds
        let path = CGMutablePath(), outer = min(bounds.width, bounds.height) * 0.4
        for i in 0..<8 {
            let angle = CGFloat(i) * .pi / 4 - .pi / 2
            let radius = i.isMultiple(of: 2) ? outer : outer * 0.15
            let p = CGPoint(x: bounds.midX + cos(angle) * radius, y: bounds.midY + sin(angle) * radius)
            if i == 0 { path.move(to: p) } else { path.addLine(to: p) }
        }
        path.closeSubpath(); star.path = path
    }
}

@MainActor final class KeyManager: NSObject, NSApplicationDelegate {
    private var window: NSWindow!
    private var customer: NSTextField!
    private var days: NSTextField!
    private var output: NSTextView!
    private var status: NSTextField!
    private var latestKey = ""
    private let script = FileManager.default.homeDirectoryForCurrentUser
        .appendingPathComponent("Downloads/AVERA-Offline-Licensing/avera_licenses.py").path

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        let size = NSSize(width: 1080, height: 700)
        window = NSWindow(contentRect: NSRect(origin: .zero, size: size), styleMask: [.titled, .closable, .miniaturizable, .fullSizeContentView], backing: .buffered, defer: false)
        window.title = "AVERA Key Manager"; window.titleVisibility = .hidden
        window.titlebarAppearsTransparent = true; window.isReleasedWhenClosed = false
        window.isOpaque = false; window.backgroundColor = .clear
        window.appearance = NSAppearance(named: .darkAqua)
        window.center()
        let root = NSView(frame: NSRect(origin: .zero, size: size)); root.wantsLayer = true
        root.layer?.backgroundColor = NSColor.black.withAlphaComponent(0.9).cgColor
        window.contentView = root

        let side = glass(NSRect(x: 14, y: 14, width: 240, height: 672))
        root.addSubview(side)
        side.addSubview(StarView(frame: NSRect(x: 23, y: 555, width: 65, height: 65)))
        let brand = label("AVERA", 25, .semibold); brand.frame = NSRect(x: 88, y: 578, width: 125, height: 32); side.addSubview(brand)
        let sub = label("KEY MANAGER", 10, .medium, 0.55); sub.frame = NSRect(x: 90, y: 558, width: 135, height: 20); side.addSubview(sub)
        let section = label("OFFLINE LICENSING", 11, .semibold, 0.55)
        section.frame = NSRect(x: 25, y: 475, width: 195, height: 20); side.addSubview(section)
        let hint = label("Signed licenses\nNo server required\nPrivate key stays on this Mac", 13, .regular, 0.72)
        hint.frame = NSRect(x: 25, y: 380, width: 190, height: 80)
        hint.maximumNumberOfLines = 4; side.addSubview(hint)
        let foot = label("AVERA  ·  OWNER TOOLS", 10, .medium, 0.48)
        foot.frame = NSRect(x: 24, y: 28, width: 205, height: 20); side.addSubview(foot)

        let main = glass(NSRect(x: 269, y: 14, width: 797, height: 672)); root.addSubview(main)
        let title = label("License Control", 30, .semibold); title.frame = NSRect(x: 33, y: 598, width: 550, height: 43); main.addSubview(title)
        let subtitle = label("Generate and manage cryptographically signed AVERA keys.", 13, .regular, 0.65)
        subtitle.frame = NSRect(x: 35, y: 568, width: 710, height: 25); main.addSubview(subtitle)
        let customerLabel = label("CUSTOMER NAME", 11, .semibold, 0.6)
        customerLabel.frame = NSRect(x: 35, y: 508, width: 220, height: 22); main.addSubview(customerLabel)
        customer = field("Customer name", NSRect(x: 35, y: 462, width: 445, height: 40)); main.addSubview(customer)
        let daysLabel = label("VALIDITY (DAYS — 0 = NEVER)", 11, .semibold, 0.6)
        daysLabel.frame = NSRect(x: 500, y: 508, width: 270, height: 22); main.addSubview(daysLabel)
        days = field("0", NSRect(x: 500, y: 462, width: 255, height: 40)); days.stringValue = "0"; main.addSubview(days)
        main.addSubview(button("✦  Generate License", NSRect(x: 35, y: 399, width: 220, height: 44), #selector(issue)))
        main.addSubview(button("Copy Key", NSRect(x: 270, y: 399, width: 120, height: 44), #selector(copyKey)))
        main.addSubview(button("License History", NSRect(x: 405, y: 399, width: 170, height: 44), #selector(showHistory)))
        main.addSubview(button("Verify Key", NSRect(x: 590, y: 399, width: 165, height: 44), #selector(verifyPrompt)))
        main.addSubview(button("Delete Key", NSRect(x: 35, y: 347, width: 175, height: 40), #selector(deleteOne)))
        main.addSubview(button("Delete All Keys", NSRect(x: 225, y: 347, width: 175, height: 40), #selector(deleteAll)))
        let outTitle = label("LICENSE OUTPUT / HISTORY", 11, .semibold, 0.6)
        outTitle.frame = NSRect(x: 35, y: 312, width: 370, height: 22); main.addSubview(outTitle)
        let scroll = NSScrollView(frame: NSRect(x: 35, y: 94, width: 720, height: 210))
        scroll.wantsLayer = true; scroll.layer?.cornerRadius = 12
        scroll.layer?.backgroundColor = NSColor.white.withAlphaComponent(0.05).cgColor
        scroll.hasVerticalScroller = true; scroll.drawsBackground = false
        output = NSTextView(frame: scroll.bounds)
        output.isEditable = false; output.isSelectable = true
        output.drawsBackground = false; output.textColor = .white
        output.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
        output.textContainerInset = NSSize(width: 14, height: 16)
        output.string = "Ready to generate your first license.\n\nYour existing signing keys will be reused."
        scroll.documentView = output; main.addSubview(scroll)
        status = label("Ready  ·  Signing keys stored locally", 12, .regular, 0.6)
        status.frame = NSRect(x: 35, y: 40, width: 720, height: 25); main.addSubview(status)
        window.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps: true)
    }

    private func glass(_ rect: NSRect) -> NSVisualEffectView {
        let v = NSVisualEffectView(frame: rect)
        v.material = .hudWindow; v.blendingMode = .behindWindow; v.state = .active
        v.wantsLayer = true; v.layer?.cornerRadius = 20; v.layer?.masksToBounds = true
        v.layer?.borderWidth = 1; v.layer?.borderColor = NSColor.white.withAlphaComponent(0.17).cgColor
        return v
    }
    private func label(_ text: String, _ size: CGFloat, _ weight: NSFont.Weight, _ alpha: CGFloat = 1) -> NSTextField {
        let v = NSTextField(labelWithString: text)
        v.font = .systemFont(ofSize: size, weight: weight)
        v.textColor = NSColor.white.withAlphaComponent(alpha); v.backgroundColor = .clear
        return v
    }
    private func field(_ placeholder: String, _ rect: NSRect) -> NSTextField {
        let v = NSTextField(frame: rect); v.placeholderString = placeholder
        v.font = .systemFont(ofSize: 15); v.textColor = .white
        v.isBezeled = false; v.drawsBackground = true
        v.backgroundColor = NSColor.white.withAlphaComponent(0.075)
        v.wantsLayer = true; v.layer?.cornerRadius = 10
        return v
    }
    private func button(_ title: String, _ rect: NSRect, _ action: Selector) -> NSButton {
        let b = GlowButton(title: title, target: self, action: action)
        b.frame = rect; b.isBordered = false
        b.font = .systemFont(ofSize: 13, weight: .medium)
        b.contentTintColor = .white; b.wantsLayer = true
        b.layer?.cornerRadius = 11
        b.layer?.backgroundColor = NSColor.white.withAlphaComponent(0.07).cgColor
        return b
    }
    private func execute(_ args: [String]) -> (Int32, String) {
        guard FileManager.default.fileExists(atPath: script) else {
            return (1, "Cannot find avera_licenses.py at:\n\(script)\n\nKeep the AVERA-Offline-Licensing folder in Downloads.")
        }
        let process = Process(); process.executableURL = URL(fileURLWithPath: "/usr/bin/env")
        process.arguments = ["python3", script] + args
        let pipe = Pipe(); process.standardOutput = pipe; process.standardError = pipe
        do {
            try process.run()
            let data = pipe.fileHandleForReading.readDataToEndOfFile()
            process.waitUntilExit()
            return (process.terminationStatus, String(decoding: data, as: UTF8.self))
        } catch { return (1, error.localizedDescription) }
    }
    @objc private func issue() {
        let name = customer.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { status.stringValue = "Enter a customer name first."; return }
        guard let n = Int(days.stringValue), n >= 0, n <= 36500 else {
            status.stringValue = "Validity must be a whole number from 0 to 36500."; return
        }
        let (code, result) = execute(["issue", "--customer", name, "--days", String(n)])
        output.string = result
        if code == 0 {
            latestKey = result.components(separatedBy: .whitespacesAndNewlines).first(where: { $0.hasPrefix("AVERA1.") }) ?? ""
            status.stringValue = latestKey.isEmpty ? "License issued; check output." : "License generated successfully. Use Copy Key."
        } else { status.stringValue = "Could not issue license — see output." }
    }
    @objc private func copyKey() {
        guard !latestKey.isEmpty else { status.stringValue = "Generate a license before copying."; return }
        NSPasteboard.general.clearContents(); NSPasteboard.general.setString(latestKey, forType: .string)
        status.stringValue = "Activation key copied to clipboard."
    }
    @objc private func showHistory() {
        let (code, result) = execute(["list"])
        output.string = result.isEmpty ? "No license history returned." : result
        status.stringValue = code == 0 ? "Local license records loaded." : "Could not load license records."
    }
    @objc private func deleteOne() {
        let (code, result) = execute(["list"])
        guard code == 0 else { output.string = result; status.stringValue = "Could not load license history."; return }
        let lines = result.split(separator: "\n").map(String.init).filter { $0.contains(" | ") }
        guard !lines.isEmpty else { status.stringValue = "No saved licenses to delete."; return }

        let alert = NSAlert()
        alert.messageText = "Delete a saved license?"
        alert.informativeText = "Choose a license to remove from this Mac's history. Already-issued offline activation keys will still work."
        alert.addButton(withTitle: "Continue")
        alert.addButton(withTitle: "Cancel")
        let popup = NSPopUpButton(frame: NSRect(x: 0, y: 0, width: 490, height: 30), pullsDown: false)
        popup.addItems(withTitles: lines)
        alert.accessoryView = popup
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let selected = lines[popup.indexOfSelectedItem]
        guard let licenseID = selected.components(separatedBy: " | ").first, !licenseID.isEmpty else { return }

        let confirm = NSAlert()
        confirm.alertStyle = .warning
        confirm.messageText = "Delete license \(licenseID)?"
        confirm.informativeText = "This removes the saved record only. It cannot disable a key already in use."
        confirm.addButton(withTitle: "Delete Key")
        confirm.addButton(withTitle: "Cancel")
        guard confirm.runModal() == .alertFirstButtonReturn else { return }
        let (deleteCode, message) = execute(["delete", licenseID])
        if deleteCode == 0 {
            let (_, history) = execute(["list"])
            output.string = history.isEmpty ? "No saved licenses." : history
            status.stringValue = "Deleted license \(licenseID) from local history."
        } else { output.string = message; status.stringValue = "Could not delete license." }
    }

    @objc private func deleteAll() {
        let (code, history) = execute(["list"])
        guard code == 0 else { output.string = history; status.stringValue = "Could not load license history."; return }
        let count = history.split(separator: "\n").filter { $0.contains(" | ") }.count
        guard count > 0 else { status.stringValue = "No saved licenses to delete."; return }
        let confirm = NSAlert()
        confirm.alertStyle = .warning
        confirm.messageText = "Delete ALL \(count) saved licenses?"
        confirm.informativeText = "This clears the entire local license history. Your private and public signing keys stay safe. Previously distributed activation keys will still work. This cannot be undone."
        confirm.addButton(withTitle: "Delete All Keys")
        confirm.addButton(withTitle: "Cancel")
        guard confirm.runModal() == .alertFirstButtonReturn else { return }
        let (deleteCode, message) = execute(["delete-all"])
        output.string = message
        status.stringValue = deleteCode == 0 ? "All local license records deleted." : "Could not clear license records."
    }

    @objc private func verifyPrompt() {
        let alert = NSAlert(); alert.messageText = "Verify AVERA license"
        alert.informativeText = "Paste the complete AVERA1 activation key."
        alert.addButton(withTitle: "Verify"); alert.addButton(withTitle: "Cancel")
        let f = NSTextField(frame: NSRect(x: 0, y: 0, width: 440, height: 26))
        f.placeholderString = "AVERA1...."; alert.accessoryView = f
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let key = f.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return }
        let (code, result) = execute(["verify", "--key", key])
        output.string = result; status.stringValue = code == 0 ? "Verification completed." : "Verification failed — see output."
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }
}

@main struct Main {
    @MainActor static func main() {
        let app = NSApplication.shared
        let delegate = KeyManager(); app.delegate = delegate
        app.run()
    }
}
