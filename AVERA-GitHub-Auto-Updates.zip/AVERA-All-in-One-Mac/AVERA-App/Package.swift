// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "AVERA",
    platforms: [.macOS(.v12)],
    products: [
        .executable(name: "AVERA", targets: ["AVERA"])
    ],
    targets: [
        .executableTarget(name: "AVERA", path: "Sources/AVERA")
    ]
)
