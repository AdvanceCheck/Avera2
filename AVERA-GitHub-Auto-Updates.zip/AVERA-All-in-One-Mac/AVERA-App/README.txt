AVERA MAC — OFFLINE ACTIVATION

1. Keep your existing AVERA installation closed.
2. Extract this ZIP into Downloads.
3. In Terminal:
   cd ~/Downloads/AVERA-Activated-Mac
   bash install.sh

The installer reads ONLY your public signing key from:
  ~/.avera-license-manager/signing-public.pem
It embeds the public key into the app binary and NEVER bundles your private key.
It automatically backs up your previous ~/Applications/AVERA.app before installing.

First launch: enter your username, password, and a signed AVERA1 activation key.
Later launches: only username and password, unless the license expires or is invalid.

Your existing macOS Keychain account, Gemini API key, chats and memories are preserved.

Important: offline licenses cannot be remotely revoked or securely limited to one device.
The license is checked on startup; the app is not resistant to reverse-engineering.
This build is for macOS; the Windows port is a separate future project.
