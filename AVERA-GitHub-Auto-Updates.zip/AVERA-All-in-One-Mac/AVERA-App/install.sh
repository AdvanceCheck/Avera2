#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
if [[ "$(uname -s)" != "Darwin" ]]; then echo 'This installer requires macOS.'; exit 1; fi
python3 prepare-license.py
swift build -c release
APP="$HOME/Applications/AVERA.app"
if [[ -d "$APP" ]]; then
  BACKUP="$HOME/Applications/AVERA-backup-$(date +%Y%m%d-%H%M%S).app"
  cp -R "$APP" "$BACKUP"
  echo "Backup saved: $BACKUP"
fi
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp .build/release/AVERA "$APP/Contents/MacOS/AVERA"
cp "$ROOT/discord_rpc.py" "$APP/Contents/Resources/discord_rpc.py"
cp "$ROOT/avera_updater.py" "$APP/Contents/Resources/avera_updater.py"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>NSScreenCaptureDescription</key><string>AVERA analyzes your screen when you enable live screen analysis.</string>
<key>CFBundleName</key><string>AVERA</string>
<key>CFBundleIdentifier</key><string>com.avera.desktop</string>
<key>CFBundleExecutable</key><string>AVERA</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleVersion</key><string>1.2.0</string>
<key>LSMinimumSystemVersion</key><string>12.0</string>
</dict></plist>
PLIST
printf 'Installed: %s\n' "$APP"
open "$APP"
