#!/usr/bin/env python3
"""AVERA Discord Rich Presence: local IPC only; no tokens or Discord account credentials."""
import json, os, socket, struct, sys, time, tempfile

def frame(opcode, payload):
    raw = json.dumps(payload, separators=(',', ':')).encode('utf-8')
    return struct.pack('<II', opcode, len(raw)) + raw

def receive(sock):
    head = b''
    while len(head) < 8:
        chunk = sock.recv(8-len(head))
        if not chunk: raise ConnectionError('closed')
        head += chunk
    opcode, size = struct.unpack('<II', head)
    if size > 1024*1024: raise ValueError('invalid RPC frame')
    while size:
        chunk = sock.recv(min(size, 65536))
        if not chunk: raise ConnectionError('closed')
        size -= len(chunk)
    return opcode

def run(client_id):
    paths = []
    for base in [os.environ.get('XDG_RUNTIME_DIR'), os.environ.get('TMPDIR'), tempfile.gettempdir(), '/tmp']:
        if base:
            for i in range(10): paths.append(os.path.join(base, 'discord-ipc-%d' % i))
    for path in dict.fromkeys(paths):
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
                sock.settimeout(4)
                sock.connect(path)
                sock.sendall(frame(0, {'v':1,'client_id':client_id}))
                receive(sock)
                sock.sendall(frame(1, {'cmd':'SET_ACTIVITY','args':{'pid':os.getppid(),'activity':{'details':'Using AVERA','state':'Local AI assistant','timestamps':{'start':int(time.time())}}},'nonce':str(time.time_ns())}))
                receive(sock)
                while True:
                    time.sleep(30)
                    sock.sendall(frame(3, {}))
                    receive(sock)
        except (OSError, ValueError, ConnectionError):
            continue

if __name__ == '__main__' and len(sys.argv) == 2 and sys.argv[1].isdigit():
    while True:
        run(sys.argv[1])
        time.sleep(15)
