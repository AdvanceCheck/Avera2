#!/usr/bin/env python3
"""Embed the owner's PUBLIC Ed25519 key in the app. Standard library only."""
import base64, pathlib, re, sys
root = pathlib.Path(__file__).resolve().parent
public_path = pathlib.Path.home() / '.avera-license-manager' / 'signing-public.pem'
if not public_path.exists():
    sys.exit('ERROR: Missing ~/.avera-license-manager/signing-public.pem. Run your license manager init first.')
raw = base64.b64decode(''.join(line.strip() for line in public_path.read_text().splitlines() if not line.startswith('-----')))
# RFC 8410 SubjectPublicKeyInfo DER header for Ed25519
header = bytes.fromhex('302a300506032b6570032100')
if not raw.startswith(header) or len(raw) != len(header) + 32:
    sys.exit('ERROR: Public key is not an Ed25519 PEM public key.')
value = base64.b64encode(raw[len(header):]).decode()
path = root / 'Sources' / 'AVERA' / 'LicenseVerifier.swift'
source = path.read_text()
source = re.sub(r'(static let publicKeyBase64 = ")[^"]*(")', lambda m: m.group(1) + value + m.group(2), source)
path.write_text(source)
print('Your public verification key is embedded. Private signing key remains untouched.')
