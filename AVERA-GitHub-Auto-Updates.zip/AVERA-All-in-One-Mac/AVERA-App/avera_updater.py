#!/usr/bin/env python3
"""AVERA release updater; only installs versioned AVERA-macos.zip with matching SHA-256."""
import argparse, hashlib, json, os, pathlib, shutil, sys, tempfile, time, urllib.request, zipfile
REPO = 'AdvanceCheck/Avera2'
API = f'https://api.github.com/repos/{REPO}/releases/latest'
CACHE = pathlib.Path.home() / 'Library' / 'Application Support' / 'AVERA' / 'updates'
MAX_BYTES = 180_000_000

def output(ok, message, **extra):
    print(json.dumps(dict(ok=ok, message=message, **extra)), flush=True)
    if not ok: sys.exit(1)

def fetch(url, limit=MAX_BYTES):
    if not url.startswith('https://') or not (url.startswith('https://api.github.com/') or url.startswith('https://github.com/') or url.startswith('https://release-assets.githubusercontent.com/') or url.startswith('https://objects.githubusercontent.com/')):
        raise ValueError('Unexpected download host')
    req = urllib.request.Request(url, headers={'User-Agent': 'AVERA-Updater/1.2', 'Accept': 'application/vnd.github+json'})
    with urllib.request.urlopen(req, timeout=35) as res:
        if not res.url.startswith('https://'):
            raise ValueError('Unsafe redirect')
        data = res.read(limit+1)
        if len(data) > limit: raise ValueError('Download too large')
        return data

def version(v):
    v = v.lstrip('vV').split('-',1)[0]
    pieces=v.split('.')
    if len(pieces)>4 or not all(p.isdecimal() for p in pieces): return (0,)
    return tuple(int(p) for p in pieces)

def check(current):
    release=json.loads(fetch(API, 2_000_000))
    tag=release.get('tag_name','')
    if release.get('draft') or release.get('prerelease') or version(tag) <= version(current):
        output(True, 'AVERA is up to date.', available=False)
    assets={a['name']:a['browser_download_url'] for a in release.get('assets',[]) if 'name' in a and 'browser_download_url' in a}
    if 'AVERA-macos.zip' not in assets or 'AVERA-macos.zip.sha256' not in assets:
        output(True, 'New release exists but macOS update files are not published yet.', available=False)
    output(True, f'AVERA {tag} is available.', available=True, asset_url=assets['AVERA-macos.zip'], sha256_url=assets['AVERA-macos.zip.sha256'])

def download(asset, checksum):
    if not asset.startswith(f'https://github.com/{REPO}/releases/download/') or not checksum.startswith(f'https://github.com/{REPO}/releases/download/'):
        output(False, 'Update URLs are not from the configured AVERA repository.')
    expected=fetch(checksum, 1024).decode().strip().split()[0].lower()
    if len(expected)!=64 or any(c not in '0123456789abcdef' for c in expected): output(False, 'Invalid release checksum.')
    data=fetch(asset)
    if hashlib.sha256(data).hexdigest()!=expected: output(False, 'Update checksum did not match. Nothing installed.')
    CACHE.mkdir(parents=True, exist_ok=True)
    tmp=CACHE/'AVERA-macos.zip.part'
    tmp.write_bytes(data)
    os.replace(tmp,CACHE/'AVERA-macos.zip')
    output(True, 'Update downloaded and verified; it will install when AVERA closes.')

def install(pid, app):
    archive=CACHE/'AVERA-macos.zip'
    target=pathlib.Path(app).resolve()
    if not archive.is_file() or target.name!='AVERA.app' or not target.is_dir(): return
    # Wait until original app has quit; never replace a running executable.
    for _ in range(120):
        try: os.kill(pid, 0)
        except ProcessLookupError: break
        except PermissionError: return
        time.sleep(0.5)
    else: return
    staging=pathlib.Path(tempfile.mkdtemp(prefix='avera-update-',dir=str(target.parent)))
    backup=target.parent/'AVERA-previous.app'
    try:
        with zipfile.ZipFile(archive) as z:
            for entry in z.infolist():
                path=pathlib.PurePosixPath(entry.filename)
                if path.is_absolute() or '..' in path.parts or entry.file_size > MAX_BYTES: raise ValueError('Unsafe ZIP entry')
                mode=(entry.external_attr >> 16) & 0o170000
                if mode==0o120000: raise ValueError('ZIP symlink not allowed')
            z.extractall(staging)
        candidate=staging/'AVERA.app'
        executable=candidate/'Contents'/'MacOS'/'AVERA'
        if not executable.is_file() or not (candidate/'Contents'/'Info.plist').is_file(): raise ValueError('Invalid app archive')
        executable.chmod(executable.stat().st_mode | 0o111)
        if backup.exists(): shutil.rmtree(backup)
        os.replace(target,backup)
        try: os.replace(candidate,target)
        except Exception:
            os.replace(backup,target)
            raise
        archive.unlink(missing_ok=True)
    except Exception as e:
        (CACHE/'last-error.txt').write_text(str(e))
    finally:
        shutil.rmtree(staging,ignore_errors=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=['check','download','install-on-exit'])
    parser.add_argument('--current',default='1.2.0')
    parser.add_argument('--asset')
    parser.add_argument('--sha256')
    parser.add_argument('--pid',type=int)
    parser.add_argument('--app')
    args=parser.parse_args()
    try:
        if args.command=='check': check(args.current)
        elif args.command=='download': download(args.asset or '',args.sha256 or '')
        else: install(args.pid,args.app)
    except Exception as exc: output(False,str(exc))
