AVERA screen analysis: opt-in local Ollama vision, model gemma3:4b.
Screen Recording permission required. Screenshots remain in RAM and are sent
only to the local Ollama endpoint at 127.0.0.1:11434.
Stop Screen Analysis to stop captures. The server must be running.
