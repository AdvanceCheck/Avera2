import AppKit
import CoreGraphics
import ApplicationServices
import Foundation
import Security
import QuartzCore

struct SavedChat: Codable {
    var id: UUID
    var title: String
    var updated: Date
    var messages: [[String: String]]
}

struct AVERAMemoryStore: Codable {
    var facts: [String] = []
}


// Responsive navigation buttons with spring-like scale, lift, and glow.
@MainActor
final class AVERAHoverButton: NSButton {
    private var tracking: NSTrackingArea?
    private var hovering = false

    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        if let tracking { removeTrackingArea(tracking) }
        let area = NSTrackingArea(rect: bounds, options: [.mouseEnteredAndExited, .activeInKeyWindow, .inVisibleRect], owner: self, userInfo: nil)
        addTrackingArea(area)
        tracking = area
    }

    override func mouseEntered(with event: NSEvent) {
        super.mouseEntered(with: event)
        animateHover(true)
    }

    override func mouseExited(with event: NSEvent) {
        super.mouseExited(with: event)
        animateHover(false)
    }

    private func animateHover(_ active: Bool) {
        guard hovering != active else { return }
        hovering = active
        wantsLayer = true
        guard let layer else { return }
        let color = NSColor.white.withAlphaComponent(active ? 0.105 : 0.0).cgColor
        let tint = CABasicAnimation(keyPath: "backgroundColor")
        tint.fromValue = layer.presentation()?.backgroundColor ?? layer.backgroundColor
        tint.toValue = color
        tint.duration = 0.25
        layer.add(tint, forKey: "hoverTint")
        layer.backgroundColor = color

        let scale = CASpringAnimation(keyPath: "transform.scale")
        scale.fromValue = active ? 1.0 : 1.055
        scale.toValue = active ? 1.055 : 1.0
        scale.mass = 0.8
        scale.stiffness = 260
        scale.damping = 17
        scale.initialVelocity = 0
        scale.duration = scale.settlingDuration
        layer.add(scale, forKey: "hoverScale")

        let shine = CABasicAnimation(keyPath: "shadowOpacity")
        shine.fromValue = layer.presentation()?.shadowOpacity ?? (active ? 0 : 0.38)
        shine.toValue = active ? 0.38 : 0.0
        shine.duration = 0.22
        layer.shadowColor = NSColor.white.cgColor
        layer.shadowRadius = 17
        layer.shadowOffset = .zero
        layer.shadowOpacity = active ? 0.22 : 0
        layer.add(shine, forKey: "hoverGlow")
    }

    override func mouseDown(with event: NSEvent) {
        let bounce = CAKeyframeAnimation(keyPath: "transform.scale")
        bounce.values = [1.04, 0.91, 1.08, 1.0]
        bounce.keyTimes = [0, 0.24, 0.65, 1]
        bounce.duration = 0.38
        layer?.add(bounce, forKey: "clickBounce")
        super.mouseDown(with: event)
    }
}

// Decorative overlay on top of native macOS vibrancy.
@MainActor
final class AVERAGlassGlow: NSView {
    private let borderLayer = CAShapeLayer()
    private let sweepLayer = CAGradientLayer()
    private let haloLayer = CAGradientLayer()

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
        layer?.masksToBounds = true
        layer?.cornerRadius = 20
        // Ambient radial light moves softly across the glass.
        haloLayer.colors = [NSColor.white.withAlphaComponent(0.006).cgColor,
                            NSColor.white.withAlphaComponent(0.001).cgColor,
                            NSColor.clear.cgColor]
        haloLayer.startPoint = CGPoint(x: 0, y: 1)
        haloLayer.endPoint = CGPoint(x: 1, y: 0)
        layer?.addSublayer(haloLayer)
        let breathe = CABasicAnimation(keyPath: "opacity")
        breathe.fromValue = 0.35
        breathe.toValue = 1.0
        breathe.duration = 3.0
        breathe.autoreverses = true
        breathe.repeatCount = .infinity
        haloLayer.add(breathe, forKey: "ambientBreathing")

        sweepLayer.colors = [NSColor.clear.cgColor,
                             NSColor.white.withAlphaComponent(0.024).cgColor,
                             NSColor.clear.cgColor]
        sweepLayer.locations = [0, 0.5, 1]
        sweepLayer.startPoint = CGPoint(x: 0, y: 0)
        sweepLayer.endPoint = CGPoint(x: 1, y: 1)
        sweepLayer.opacity = 0.22
        layer?.addSublayer(sweepLayer)
        let sweep = CABasicAnimation(keyPath: "transform.translation.x")
        sweep.fromValue = -700
        sweep.toValue = 900
        sweep.duration = 8
        sweep.beginTime = CACurrentMediaTime() + 0.7
        sweep.repeatCount = .infinity
        sweep.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        sweepLayer.add(sweep, forKey: "lightSweep")

        borderLayer.fillColor = NSColor.clear.cgColor
        borderLayer.strokeColor = NSColor.white.withAlphaComponent(0.20).cgColor
        borderLayer.lineWidth = 1.1
        layer?.addSublayer(borderLayer)
        let borderPulse = CABasicAnimation(keyPath: "opacity")
        borderPulse.fromValue = 0.22
        borderPulse.toValue = 0.85
        borderPulse.duration = 2.4
        borderPulse.autoreverses = true
        borderPulse.repeatCount = .infinity
        borderLayer.add(borderPulse, forKey: "borderPulse")
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func layout() {
        super.layout()
        haloLayer.frame = bounds
        sweepLayer.frame = bounds
        borderLayer.frame = bounds
        borderLayer.path = CGPath(roundedRect: bounds.insetBy(dx: 1, dy: 1),
                                  cornerWidth: 19, cornerHeight: 19, transform: nil)
    }

    override func hitTest(_ point: NSPoint) -> NSView? { nil }
}

// Vector-drawn star so the logo is visible even with transparent vibrancy.
@MainActor
final class AVERAStarView: NSView {
    private let starLayer = CAShapeLayer()

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
        starLayer.fillColor = NSColor.white.cgColor
        starLayer.shadowColor = NSColor.white.cgColor
        starLayer.shadowRadius = 13
        starLayer.shadowOpacity = 0.85
        starLayer.shadowOffset = .zero
        layer?.addSublayer(starLayer)
        startIdle()
        let breath = CABasicAnimation(keyPath: "shadowRadius")
        breath.fromValue = 5
        breath.toValue = 21
        breath.duration = 2.1
        breath.autoreverses = true
        breath.repeatCount = .infinity
        starLayer.add(breath, forKey: "breath")
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    override func layout() {
        super.layout()
        starLayer.frame = bounds
        let cx = bounds.midX, cy = bounds.midY
        let outer = min(bounds.width, bounds.height) * 0.39
        let inner = outer * 0.15
        let path = CGMutablePath()
        for i in 0..<8 {
            let angle = CGFloat(i) * .pi / 4 - .pi / 2
            let r = i.isMultiple(of: 2) ? outer : inner
            let point = CGPoint(x: cx + cos(angle) * r, y: cy + sin(angle) * r)
            if i == 0 { path.move(to: point) } else { path.addLine(to: point) }
        }
        path.closeSubpath()
        starLayer.path = path
    }

    private func startIdle() {
        let spin = CABasicAnimation(keyPath: "transform.rotation.z")
        spin.fromValue = 0
        spin.toValue = Double.pi * 2
        spin.duration = 16
        spin.repeatCount = .infinity
        starLayer.add(spin, forKey: "idle")
    }

    func setThinking(_ thinking: Bool) {
        starLayer.removeAnimation(forKey: "idle")
        starLayer.removeAnimation(forKey: "thinking")
        if thinking {
            let spin = CABasicAnimation(keyPath: "transform.rotation.z")
            spin.fromValue = 0
            spin.toValue = Double.pi * 2
            spin.duration = 0.95
            spin.repeatCount = .infinity
            starLayer.add(spin, forKey: "thinking")
        } else { startIdle() }
    }
}

@MainActor
final class AVERAController: NSObject, NSApplicationDelegate {
    private var window: NSWindow!
    private var root: NSView!
    private var chatView: NSTextView!
    private var input: NSTextField!
    private var sendButton: NSButton!
    private var statusLabel: NSTextField!
    private var star: AVERAStarView!
    private var thinkingLabel: NSTextField!
    private var thinkingTimer: Timer?
    private var thinkingStep = 0
    private var messages: [[String: String]] = []
    private var busy = false
    private var streamingText = ""
    private var settingsPanel: NSView?
    private var settingsKeyField: NSSecureTextField?
    private var settingsModelPopup: NSPopUpButton?
    private var chats: [SavedChat] = []
    private var currentID = UUID()
    private var chatScroll: NSScrollView!
    private var historyButton: NSButton!
    private var searchField: NSSearchField!
    private var historyPanel: NSView?
    private var memoryPanel: NSView?
    private var loginWindow: NSWindow?
    private var loginUsernameField: NSTextField?
    private var loginPasswordField: NSSecureTextField?
    private var loginStatusLabel: NSTextField?
    private var activationField: NSTextField?
    private let activationAccount = "signed-activation-license"
    private var memoryInput: NSTextField?
    private var keyOutput: NSTextField?
    private var memories: [String] = []
    private let accountService = "com.avera.local-account"
    private let accountUsername = "username"
    private let accountPassword = "password"
    private let activationCodesURL = FileManager.default.homeDirectoryForCurrentUser
        .appendingPathComponent("Library/Application Support/AVERA/activation-codes.txt")
    private let storageURL = FileManager.default.homeDirectoryForCurrentUser
        .appendingPathComponent("Library/Application Support/AVERA/chats.json")
    private let memoryURL = FileManager.default.homeDirectoryForCurrentUser
        .appendingPathComponent("Library/Application Support/AVERA/memory.json")
    private var screenTimer: Timer?
    private var screenActive = false
    private var screenBusy = false
    private var latestScreenJPEG: Data?
    private var screenToggleButton: NSButton?
    private var screenInsightLabel: NSTextField?
    private var floatingPanel: NSPanel?
    private var floatingTranscript: NSTextView?
    private var floatingInput: NSTextField?
    private var floatingStatus: NSTextField?
    private var ollamaServerProcess: Process?
    private var modelName = "gemma3:4b"
    private var responseMode = UserDefaults.standard.string(forKey: "avera.responseMode") ?? "Balanced"
    private var controlPermission = UserDefaults.standard.string(forKey: "avera.controlPermission") ?? "Automatic"
    private var screenControlEnabled = false
    private var responseModePopup: NSPopUpButton?
    private var controlPermissionPopup: NSPopUpButton?
    private var discordToggle: NSButton?
    private var discordAppIDField: NSTextField?
    private var discordRPCProcess: Process?
    private var discordEnabled = UserDefaults.standard.bool(forKey: "avera.discordEnabled")
    private var discordAppID = UserDefaults.standard.string(forKey: "avera.discordAppID") ?? ""
    private var loadingWindow: NSWindow?
    private var autoUpdates = UserDefaults.standard.object(forKey: "avera.autoUpdates") as? Bool ?? true
    private var updateToggle: NSButton?
    private var updateStatusLabel: NSTextField?
    private var stagedUpdate = false
    private let appVersion = "1.2.0"

    private let keyService = "com.avera.gemini"
    private let keyAccount = "gemini-api-key"

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        startOllamaIfNeeded()
        showLoginScreen()
        NSApp.activate(ignoringOtherApps: true)
        if autoUpdates { checkForUpdates(silent: true) }
    }

    // Starts the local Ollama server without opening a Terminal window.
    // Only starts a process if no server is already responding.
    private func startOllamaIfNeeded() {
        guard let url = URL(string: "http://127.0.0.1:11434/api/version") else { return }
        var request = URLRequest(url: url)
        request.timeoutInterval = 2
        URLSession.shared.dataTask(with: request) { [weak self] _, response, _ in
            if let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) { return }
            DispatchQueue.main.async { [weak self] in self?.launchOllamaServer() }
        }.resume()
    }

    private func launchOllamaServer() {
        guard ollamaServerProcess == nil else { return }
        let candidates = ["/opt/homebrew/bin/ollama", "/usr/local/bin/ollama", "/usr/bin/ollama"]
        guard let executable = candidates.first(where: { FileManager.default.isExecutableFile(atPath: $0) }) else {
            NSLog("AVERA: Ollama executable not found; install Ollama first.")
            return
        }
        let process = Process()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = ["serve"]
        process.standardOutput = FileHandle.nullDevice
        process.standardError = FileHandle.nullDevice
        do {
            try process.run()
            ollamaServerProcess = process
            NSLog("AVERA: Started local Ollama server in background.")
        } catch {
            NSLog("AVERA: Could not start Ollama: \(error.localizedDescription)")
        }
    }

    func applicationWillTerminate(_ notification: Notification) {
        // Only stop the Ollama process launched by this AVERA session.
        // Never shut down a server that was already running before AVERA opened.
        screenTimer?.invalidate()
        screenTimer = nil
        screenActive = false
        stopDiscordRPC()
        if stagedUpdate { installStagedUpdateAfterQuit() }
        if let process = ollamaServerProcess {
            if process.isRunning {
                process.terminate()
                NSLog("AVERA: Stopped the Ollama server started by AVERA.")
            }
            ollamaServerProcess = nil
        }
    }

    private func showLoginScreen() {
        let size = NSSize(width: 1120, height: 720)
        let w = NSWindow(contentRect: NSRect(origin: .zero, size: size),
                         styleMask: [.titled, .closable, .miniaturizable, .fullSizeContentView],
                         backing: .buffered, defer: false)
        // Keep ARC in control of the window lifetime when it is hidden or closed.
        w.isReleasedWhenClosed = false
        w.title = "AVERA"
        w.titlebarAppearsTransparent = true
        w.titleVisibility = .hidden
        w.isOpaque = false
        w.backgroundColor = .clear
        w.appearance = NSAppearance(named: .darkAqua)
        w.center()
        let base = NSView(frame: NSRect(origin: .zero, size: size))
        base.wantsLayer = true
        base.layer?.backgroundColor = NSColor.clear.cgColor
        w.contentView = base
        let panel = glass(NSRect(x: 270, y: 70, width: 580, height: 580), material: .hudWindow)
        base.addSubview(panel)
        let logo = AVERAStarView(frame: NSRect(x: 248, y: 438, width: 78, height: 78))
        panel.addSubview(logo)
        let title = label("AVERA", size: 34, weight: .bold)
        title.alignment = .center
        title.frame = NSRect(x: 40, y: 395, width: 500, height: 44)
        panel.addSubview(title)
        let subtitle = label("PERSONAL INTELLIGENCE", size: 10, weight: .medium, color: .white.withAlphaComponent(0.55))
        subtitle.alignment = .center
        subtitle.frame = NSRect(x: 40, y: 370, width: 500, height: 20)
        panel.addSubview(subtitle)
        let username = NSTextField(frame: NSRect(x: 90, y: 320, width: 400, height: 42))
        username.placeholderAttributedString = NSAttributedString(string: "Username", attributes: [.foregroundColor: NSColor.white.withAlphaComponent(0.72)])
        username.stringValue = loadAccountValue(accountUsername) ?? ""
        username.font = .systemFont(ofSize: 15)
        username.textColor = .white
        username.isBezeled = false
        username.drawsBackground = true
        username.backgroundColor = NSColor.white.withAlphaComponent(0.07)
        username.wantsLayer = true
        username.layer?.cornerRadius = 10
        panel.addSubview(username)
        loginUsernameField = username
        let password = NSSecureTextField(frame: NSRect(x: 90, y: 260, width: 400, height: 42))
        password.placeholderAttributedString = NSAttributedString(string: "Password", attributes: [.foregroundColor: NSColor.white.withAlphaComponent(0.72)])
        password.font = .systemFont(ofSize: 15)
        password.textColor = .white
        password.isBezeled = false
        password.drawsBackground = true
        password.backgroundColor = NSColor.white.withAlphaComponent(0.07)
        password.wantsLayer = true
        password.layer?.cornerRadius = 10
        panel.addSubview(password)
        loginPasswordField = password
        // License is required once; the saved signed license is checked on every launch.
        let savedLicense = loadAccountValue(activationAccount) ?? ""
        let activated = AVERALicenseVerifier.verify(savedLicense) != nil
        if !activated {
            let activation = NSTextField(frame: NSRect(x: 90, y: 200, width: 400, height: 42))
            activation.placeholderAttributedString = NSAttributedString(string: "Paste your AVERA activation key", attributes: [.foregroundColor: NSColor.white.withAlphaComponent(0.72)])
            activation.font = .systemFont(ofSize: 13)
            activation.textColor = .white
            activation.isBezeled = false
            activation.drawsBackground = true
            activation.backgroundColor = NSColor.white.withAlphaComponent(0.07)
            activation.wantsLayer = true
            activation.layer?.cornerRadius = 10
            panel.addSubview(activation)
            activationField = activation
        } else {
            activationField = nil
        }
        let status = label("", size: 12, color: .white.withAlphaComponent(0.62))
        status.alignment = .center
        status.frame = NSRect(x: 60, y: activated ? 190 : 167, width: 460, height: 20)
        panel.addSubview(status)
        loginStatusLabel = status
        let submit = button(loadAccountValue(accountUsername) == nil ? "Create Account" : "Sign In",
                            frame: NSRect(x: 90, y: 92, width: 400, height: 42), action: #selector(loginAction))
        submit.layer?.backgroundColor = NSColor.white.withAlphaComponent(0.12).cgColor
        panel.addSubview(submit)
        let note = label("Your account is stored locally on this Mac.", size: 10, color: .white.withAlphaComponent(0.42))
        note.alignment = .center
        note.frame = NSRect(x: 50, y: 24, width: 480, height: 20)
        panel.addSubview(note)
        loginWindow = w
        w.makeKeyAndOrderFront(nil)
        w.makeFirstResponder(username)
    }

    private func loadAccountValue(_ account: String) -> String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: accountService, kSecAttrAccount as String: account,
            kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func saveAccountValue(_ value: String, account: String) -> Bool {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: accountService, kSecAttrAccount as String: account]
        SecItemDelete(query as CFDictionary)
        var item = query
        item[kSecValueData as String] = Data(value.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(item as CFDictionary, nil) == errSecSuccess
    }

    @objc private func loginAction() {
        let username = loginUsernameField?.stringValue.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let password = loginPasswordField?.stringValue ?? ""
        guard username.count >= 3, password.count >= 6 else {
            loginStatusLabel?.stringValue = "Use a username (3+ characters) and password (6+ characters)."
            return
        }
        // Do not create or unlock an account without a valid signed license.
        let savedLicense = loadAccountValue(activationAccount) ?? ""
        if AVERALicenseVerifier.verify(savedLicense) == nil {
            let entered = activationField?.stringValue.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            guard AVERALicenseVerifier.verify(entered) != nil else {
                loginStatusLabel?.stringValue = "Enter a valid, unexpired AVERA activation key."
                return
            }
            guard saveAccountValue(entered, account: activationAccount) else {
                loginStatusLabel?.stringValue = "Could not save activation in macOS Keychain."
                return
            }
        }
        if let savedUsername = loadAccountValue(accountUsername) {
            guard username == savedUsername, password == loadAccountValue(accountPassword) else {
                loginStatusLabel?.stringValue = "Username or password is incorrect."
                return
            }
        } else {
            guard saveAccountValue(username, account: accountUsername),
                  saveAccountValue(password, account: accountPassword) else {
                loginStatusLabel?.stringValue = "Could not save your account in Keychain."
                return
            }
        }
        loadChats()
        loadMemories()
        showLoadingScreen()
        buildWindow()
        startDiscordRPCIfNeeded()

        // Make the main window visible BEFORE dismissing the splash. Closing the
        // splash while it is the only visible window can deactivate the app.
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.loginWindow?.orderOut(nil)
            self.loadingWindow?.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.35) { [weak self] in
                guard let self else { return }
                NSApp.setActivationPolicy(.regular)
                self.window.alphaValue = 1
                self.window.level = .normal
                self.window.makeKeyAndOrderFront(nil)
                self.window.orderFrontRegardless()
                NSApp.activate(ignoringOtherApps: true)
                self.window.makeFirstResponder(self.input)
                // Order out the splash rather than closing it. A close event
                // can be interpreted as the last window closing.
                self.loadingWindow?.orderOut(nil)
                self.loadingWindow = nil
                self.loginWindow?.orderOut(nil)
                // Reassert activation on the next run-loop pass after the
                // splash has disappeared.
                DispatchQueue.main.async { [weak self] in
                    guard let self else { return }
                    self.window.makeKeyAndOrderFront(nil)
                    NSApp.activate(ignoringOtherApps: true)
                }
            }
        }
    }

    private func showLoadingScreen() {
        let w = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 430, height: 220),
                         styleMask: [.titled, .fullSizeContentView], backing: .buffered, defer: false)
        w.center()
        w.titleVisibility = .hidden
        w.titlebarAppearsTransparent = true
        w.isMovableByWindowBackground = true
        w.backgroundColor = NSColor(calibratedRed: 0.07, green: 0.09, blue: 0.14, alpha: 1)
        w.level = .floating
        let heading = NSTextField(labelWithString: "✦  AVERA")
        heading.font = .systemFont(ofSize: 35, weight: .bold)
        heading.textColor = .white
        heading.alignment = .center
        heading.frame = NSRect(x: 25, y: 118, width: 380, height: 55)
        w.contentView?.addSubview(heading)
        let subtitle = NSTextField(labelWithString: "Preparing your local AI assistant…")
        subtitle.font = .systemFont(ofSize: 13)
        subtitle.textColor = .lightGray
        subtitle.alignment = .center
        subtitle.frame = NSRect(x: 25, y: 86, width: 380, height: 24)
        w.contentView?.addSubview(subtitle)
        let progress = NSProgressIndicator(frame: NSRect(x: 85, y: 58, width: 260, height: 12))
        progress.style = .bar
        progress.isIndeterminate = true
        progress.startAnimation(nil)
        w.contentView?.addSubview(progress)
        loadingWindow = w
        w.orderFront(nil)
    }

    private func startDiscordRPCIfNeeded() {
        stopDiscordRPC()
        guard discordEnabled, discordAppID.count >= 15,
              discordAppID.allSatisfy({ $0.isNumber }) else { return }
        let script = Bundle.main.resourceURL?.appendingPathComponent("discord_rpc.py")
        guard let script, FileManager.default.fileExists(atPath: script.path) else { return }
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/python3")
        process.arguments = [script.path, discordAppID]
        process.standardOutput = FileHandle.nullDevice
        process.standardError = FileHandle.nullDevice
        do { try process.run(); discordRPCProcess = process }
        catch { NSLog("AVERA Discord RPC could not start: %@", error.localizedDescription) }
    }

    private func stopDiscordRPC() {
        if let process = discordRPCProcess, process.isRunning { process.terminate() }
        discordRPCProcess = nil
    }

    private func loadMemories() {
        guard let data = try? Data(contentsOf: memoryURL),
              let store = try? JSONDecoder().decode(AVERAMemoryStore.self, from: data) else { return }
        memories = Array(store.facts.suffix(100))
    }

    private func persistMemories() {
        do {
            try FileManager.default.createDirectory(at: memoryURL.deletingLastPathComponent(), withIntermediateDirectories: true)
            try JSONEncoder().encode(AVERAMemoryStore(facts: memories)).write(to: memoryURL, options: .atomic)
        } catch { NSLog("AVERA could not save memory: %@", error.localizedDescription) }
    }

    private func captureMemory(from text: String) {
        let lower = text.lowercased()
        let prefixes = ["remember that ", "my name is ", "i prefer ", "i like ", "i love ", "my goal is ", "i'm working on ", "i am working on "]
        guard let prefix = prefixes.first(where: { lower.hasPrefix($0) }) else { return }
        let fact = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard fact.count > prefix.count, !memories.contains(where: { $0.caseInsensitiveCompare(fact) == .orderedSame }) else { return }
        memories.append(String(fact.prefix(300)))
        memories = Array(memories.suffix(100))
        persistMemories()
    }

    private func memoryContext() -> String {
        guard !memories.isEmpty else { return "No saved personal memories yet." }
        return memories.suffix(30).map { "- " + $0 }.joined(separator: "\n")
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        // Splash/login transitions must not quit the application.
        return false
    }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        if let main = window, main.contentView != nil {
            main.makeKeyAndOrderFront(nil)
        } else if let login = loginWindow {
            login.makeKeyAndOrderFront(nil)
        }
        NSApp.activate(ignoringOtherApps: true)
        return true
    }

    private func glass(_ frame: NSRect, material: NSVisualEffectView.Material = .hudWindow) -> NSVisualEffectView {
        let view = NSVisualEffectView(frame: frame)
        view.material = material
        view.blendingMode = .behindWindow
        view.state = .active
        // CRITICAL: Keep the effect view fully opaque in compositing terms.
        // Lowering alpha fades the BLUR itself and reveals sharp windows behind it.
        view.alphaValue = 1.0
        view.wantsLayer = true
        view.layer?.cornerRadius = 20
        view.layer?.masksToBounds = true
        view.layer?.borderWidth = 1
        view.layer?.borderColor = NSColor.white.withAlphaComponent(0.16).cgColor
        // A restrained tint darkens the frosted result without disabling blur.
        let tint = NSView(frame: view.bounds)
        tint.wantsLayer = true
        tint.layer?.backgroundColor = NSColor.black.withAlphaComponent(0.12).cgColor
        tint.autoresizingMask = [.width, .height]
        view.addSubview(tint)
        let light = AVERAGlassGlow(frame: view.bounds)
        light.autoresizingMask = [.width, .height]
        view.addSubview(light)
        return view
    }

    private func label(_ value: String, size: CGFloat, weight: NSFont.Weight = .regular, color: NSColor = .white) -> NSTextField {
        let field = NSTextField(labelWithString: value)
        field.font = .systemFont(ofSize: size, weight: weight)
        field.textColor = color
        field.backgroundColor = .clear
        field.isBezeled = false
        field.drawsBackground = false
        return field
    }

    private func button(_ title: String, frame: NSRect, action: Selector, tag: Int = 0) -> NSButton {
        let b = AVERAHoverButton(title: title, target: self, action: action)
        b.frame = frame
        b.tag = tag
        b.bezelStyle = .rounded
        b.isBordered = false
        b.font = .systemFont(ofSize: 14, weight: .medium)
        b.contentTintColor = .white
        b.wantsLayer = true
        b.layer?.backgroundColor = NSColor.clear.cgColor
        b.layer?.cornerRadius = 12
        return b
    }

    private func buildWindow() {
        // Keep the exact window dimensions and panel layout from the working version.
        let size = NSSize(width: 1120, height: 720)
        window = NSWindow(contentRect: NSRect(origin: .zero, size: size), styleMask: [.titled, .closable, .miniaturizable, .resizable, .fullSizeContentView], backing: .buffered, defer: false)
        window.isReleasedWhenClosed = false
        window.title = "AVERA"
        window.titlebarAppearsTransparent = true
        window.titleVisibility = .hidden
        window.isMovableByWindowBackground = true
        window.minSize = NSSize(width: 860, height: 570)
        window.center()
        window.isOpaque = false
        window.backgroundColor = .clear
        window.hasShadow = true
        window.appearance = NSAppearance(named: .darkAqua)

        root = NSView(frame: NSRect(origin: .zero, size: size))
        root.wantsLayer = true
        root.layer?.backgroundColor = NSColor.clear.cgColor
        window.contentView = root

        let sidebar = glass(NSRect(x: 14, y: 14, width: 235, height: 692), material: .hudWindow)
        sidebar.autoresizingMask = [.height]
        root.addSubview(sidebar)

        star = AVERAStarView(frame: NSRect(x: 24, y: 598, width: 55, height: 58))
        star.autoresizingMask = [.minYMargin]
        sidebar.addSubview(star)

        let brand = label("AVERA", size: 22, weight: .semibold)
        brand.frame = NSRect(x: 83, y: 618, width: 125, height: 30)
        sidebar.addSubview(brand)
        let subtitle = label("PERSONAL INTELLIGENCE", size: 9, weight: .medium, color: .white.withAlphaComponent(0.48))
        subtitle.frame = NSRect(x: 84, y: 600, width: 145, height: 17)
        sidebar.addSubview(subtitle)

        let entries: [(String, Int)] = [("＋   New Chat", 0), ("◷   History", 1), ("◈   Plugins", 2), ("⚙   Settings", 3), ("✧   Memory", 4), ("✧   Licensed", 5)]
        for (index, entry) in entries.enumerated() {
            let b = button(entry.0, frame: NSRect(x: 17, y: 518 - CGFloat(index) * 55, width: 201, height: 43), action: #selector(navigate(_:)), tag: entry.1)
            sidebar.addSubview(b)
            if entry.1 == 1 { historyButton = b }
        }
        let screenButton = button("◉   Start Screen Analysis", frame: NSRect(x: 17, y: 105, width: 201, height: 43), action: #selector(toggleScreenAnalysis))
        sidebar.addSubview(screenButton)
        screenToggleButton = screenButton
        let screenNote = label("OFF  ·  Screen not captured", size: 10, weight: .medium, color: .white.withAlphaComponent(0.55))
        screenNote.frame = NSRect(x: 22, y: 79, width: 205, height: 19)
        sidebar.addSubview(screenNote)
        screenInsightLabel = screenNote


        let main = glass(NSRect(x: 263, y: 14, width: 843, height: 692), material: .hudWindow)
        main.autoresizingMask = [.width, .height]
        root.addSubview(main)

        let heading = label("Your space to think.", size: 29, weight: .semibold)
        heading.frame = NSRect(x: 30, y: 617, width: 580, height: 43)
        heading.autoresizingMask = [.minYMargin]
        main.addSubview(heading)
        statusLabel = label("", size: 12, weight: .medium, color: .white.withAlphaComponent(0.62))
        statusLabel.frame = NSRect(x: 32, y: 592, width: 690, height: 22)
        statusLabel.autoresizingMask = [.minYMargin, .width]
        main.addSubview(statusLabel)
        updateStatus()

        thinkingLabel = label("", size: 12, weight: .medium,
                              color: NSColor.white.withAlphaComponent(0.75))
        thinkingLabel.wantsLayer = true
        thinkingLabel.frame = NSRect(x: 32, y: 542, width: 500, height: 20)
        thinkingLabel.autoresizingMask = [.minYMargin]
        main.addSubview(thinkingLabel)

        let scroll = NSScrollView(frame: NSRect(x: 28, y: 112, width: 787, height: 465))
        scroll.autoresizingMask = [.width, .height]
        scroll.hasVerticalScroller = true
        scroll.drawsBackground = false
        scroll.borderType = .noBorder
        chatView = NSTextView(frame: scroll.bounds)
        chatView.wantsLayer = true
        chatView.isEditable = false
        chatView.isSelectable = true
        chatView.backgroundColor = .clear
        chatView.textColor = .white
        chatView.font = .systemFont(ofSize: 15)
        chatView.textContainerInset = NSSize(width: 12, height: 18)
        chatView.isVerticallyResizable = true
        chatView.autoresizingMask = [.width]
        scroll.documentView = chatView
        main.addSubview(scroll)
        chatScroll = scroll
        if let recent = chats.first {
            currentID = recent.id
            messages = recent.messages
        }
        renderMessages()

        let inputPanel = glass(NSRect(x: 28, y: 26, width: 787, height: 72), material: .hudWindow)
        inputPanel.autoresizingMask = [.width, .maxYMargin]
        main.addSubview(inputPanel)
        input = NSTextField(frame: NSRect(x: 17, y: 19, width: 640, height: 34))
        input.autoresizingMask = [.width]
        input.placeholderString = "Message AVERA..."
        input.font = .systemFont(ofSize: 15)
        input.textColor = .white
        input.backgroundColor = .clear
        input.isBezeled = false
        input.focusRingType = .none
        input.target = self
        input.action = #selector(sendMessage)
        inputPanel.addSubview(input)

        sendButton = button("↑", frame: NSRect(x: 717, y: 15, width: 52, height: 43), action: #selector(sendMessage))
        sendButton.autoresizingMask = [.minXMargin]
        sendButton.font = .systemFont(ofSize: 25, weight: .medium)
        sendButton.layer?.backgroundColor = NSColor.white.withAlphaComponent(0.035).cgColor
        inputPanel.addSubview(sendButton)

        let copy = button("Copy", frame: NSRect(x: 717, y: 593, width: 74, height: 28), action: #selector(copyConversation))
        copy.autoresizingMask = [.minXMargin, .minYMargin]
        main.addSubview(copy)
        // Login flow presents this window only AFTER the loading screen closes.
        // Keep it fully opaque to avoid an invisible/background window.
        window.alphaValue = 1
        let entrance = CABasicAnimation(keyPath: "transform.translation.y")
        entrance.fromValue = -26
        entrance.toValue = 0
        entrance.duration = 0.75
        entrance.timingFunction = CAMediaTimingFunction(name: .easeOut)
        root.layer?.add(entrance, forKey: "windowEntrance")
        window.makeFirstResponder(input)
    }

    private func updateStatus() {
        statusLabel.stringValue = "OLLAMA  ·  \(modelName)  ·  LOCAL AI"
    }

    private func saveKey(_ key: String) -> Bool {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: keyService, kSecAttrAccount as String: keyAccount]
        SecItemDelete(query as CFDictionary)
        var item = query
        item[kSecValueData as String] = Data(key.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(item as CFDictionary, nil) == errSecSuccess
    }

    private func loadKey() -> String? {
        // Also look up the account name used by earlier AVERA versions.
        for account in [keyAccount, "openai-api-key", "api-key", "AVERA"] {
            let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: keyService, kSecAttrAccount as String: account, kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
            var result: CFTypeRef?
            if SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data, let key = String(data: data, encoding: .utf8), !key.isEmpty { return key }
        }
        return nil
    }

    @objc private func navigate(_ sender: NSButton) {
        switch sender.tag {
        case 0:
            guard !busy else { return }
            saveCurrentChat()
            currentID = UUID()
            messages.removeAll()
            renderMessages()
            input.stringValue = ""
            closeHistory()
            memoryPanel?.removeFromSuperview()
            memoryPanel = nil
        case 1:
            showHistory()
        case 2:
            let alert = NSAlert()
            alert.messageText = "Plugins"
            alert.informativeText = "Plugin support is planned for a future AVERA update."
            alert.runModal()
        case 3:
            showSettings()
        case 4:
            showMemory()
        case 5:
            let alert = NSAlert()
            alert.messageText = "AVERA Licensed"
            alert.informativeText = "Your signed activation license is stored locally and checked when AVERA starts."
            alert.runModal()
        default:
            let alert = NSAlert()
            alert.messageText = sender.title
            alert.informativeText = "This feature is coming in a future update."
            alert.runModal()
        }
    }

    private func append(_ text: String) {
        chatView.string += text
        chatView.scrollToEndOfDocument(nil)
        chatView.alphaValue = 0.55
        let rise = CABasicAnimation(keyPath: "transform.translation.y")
        rise.fromValue = -13
        rise.toValue = 0
        rise.duration = 0.48
        rise.timingFunction = CAMediaTimingFunction(name: .easeOut)
        chatView.layer?.add(rise, forKey: "messageRise")
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.48
            chatView.animator().alphaValue = 1
        }
    }

    @objc private func sendMessage() {
        guard !busy else { return }
        let text = input.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        
        input.stringValue = ""
        let flash = CAKeyframeAnimation(keyPath: "transform.scale")
        flash.values = [1, 0.78, 1.22, 1]
        flash.keyTimes = [0, 0.20, 0.60, 1]
        flash.duration = 0.48
        sendButton.layer?.add(flash, forKey: "sendBurst")
        messages.append(["role": "user", "content": text])
        captureMemory(from: text)
        streamingText = ""
        saveCurrentChat()
        renderMessages()
        busy = true
        sendButton.isEnabled = false
        startThinkingAnimation()
        sendRequest()
    }

    private func navigateSettings() {
        showSettings()
    }

    // Optional compact companion window for screen analysis. The main window remains
    // available and all actions still go through the same permission controls.
    private func showFloatingPanel() {
        if let existing = floatingPanel {
            existing.makeKeyAndOrderFront(nil)
            NSApp.activate(ignoringOtherApps: true)
            return
        }
        let size = NSSize(width: 380, height: 370)
        let panel = NSPanel(contentRect: NSRect(origin: .zero, size: size),
                            styleMask: [.titled, .closable, .miniaturizable, .utilityWindow],
                            backing: .buffered, defer: false)
        panel.isReleasedWhenClosed = false
        panel.title = "AVERA · Live Assistant"
        panel.level = .floating
        panel.isMovableByWindowBackground = true
        panel.appearance = NSAppearance(named: .darkAqua)
        panel.backgroundColor = NSColor(calibratedWhite: 0.10, alpha: 0.98)
        panel.center()
        let container = NSView(frame: NSRect(origin: .zero, size: size))
        panel.contentView = container

        let status = label("LIVE · Local screen analysis", size: 12, weight: .medium,
                           color: .white.withAlphaComponent(0.85))
        status.frame = NSRect(x: 16, y: 335, width: 348, height: 22)
        container.addSubview(status)
        floatingStatus = status

        let scroll = NSScrollView(frame: NSRect(x: 14, y: 85, width: 352, height: 240))
        scroll.hasVerticalScroller = true
        scroll.drawsBackground = false
        let transcript = NSTextView(frame: scroll.bounds)
        transcript.isEditable = false
        transcript.isSelectable = true
        transcript.backgroundColor = .clear
        transcript.textColor = .white
        transcript.font = .systemFont(ofSize: 12)
        scroll.documentView = transcript
        container.addSubview(scroll)
        floatingTranscript = transcript

        let field = NSTextField(frame: NSRect(x: 14, y: 47, width: 285, height: 29))
        field.placeholderString = "Ask AVERA about your screen..."
        field.target = self
        field.action = #selector(sendFloatingMessage)
        container.addSubview(field)
        floatingInput = field

        let send = NSButton(title: "Send", target: self, action: #selector(sendFloatingMessage))
        send.frame = NSRect(x: 302, y: 47, width: 65, height: 29)
        container.addSubview(send)
        let expand = NSButton(title: "Main Window", target: self, action: #selector(showMainFromFloating))
        expand.frame = NSRect(x: 14, y: 10, width: 140, height: 30)
        container.addSubview(expand)
        let stop = NSButton(title: "Stop Analysis", target: self, action: #selector(stopFromFloating))
        stop.frame = NSRect(x: 220, y: 10, width: 145, height: 30)
        container.addSubview(stop)

        floatingPanel = panel
        refreshFloatingPanel()
        panel.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    private func refreshFloatingPanel() {
        guard let floatingPanel = floatingPanel, floatingPanel.isVisible else { return }
        floatingStatus?.stringValue = screenActive
            ? (screenControlEnabled ? "LIVE · View & Control · Local AI" : "LIVE · View Only · Local AI")
            : "OFF · Screen analysis stopped"
        let lines = messages.suffix(12).map { message in
            let name = message["role"] == "assistant" ? "AVERA" : "YOU"
            return "\(name): \(message["content"] ?? "")"
        }
        floatingTranscript?.string = lines.joined(separator: "\n\n") +
            (streamingText.isEmpty ? "" : "\n\nAVERA: " + streamingText)
        floatingTranscript?.scrollToEndOfDocument(nil)
    }

    @objc private func sendFloatingMessage() {
        guard let text = floatingInput?.stringValue.trimmingCharacters(in: .whitespacesAndNewlines),
              !text.isEmpty else { return }
        guard !busy else { NSSound.beep(); return }
        input.stringValue = text
        floatingInput?.stringValue = ""
        sendMessage()
    }

    @objc private func showMainFromFloating() {
        window.makeKeyAndOrderFront(nil)
        NSApp.activate(ignoringOtherApps: true)
    }

    @objc private func stopFromFloating() {
        stopScreenAnalysis()
    }

    // Screen analysis is opt-in and stops when the app quits or the user presses Stop.
    // Frames are held in RAM and processed by local Ollama every 15 seconds.
    @objc private func toggleScreenAnalysis() {
        if screenActive { stopScreenAnalysis(); return }
        let choice = NSAlert()
        choice.messageText = "Choose Screen Mode"
        choice.informativeText = "View Only analyzes your screen. View & Control can suggest clicks when you ask it to, using the permission mode in Settings. You can stop either mode at any time."
        choice.addButton(withTitle: "View Screen Only")
        choice.addButton(withTitle: "View & Control Screen")
        choice.addButton(withTitle: "Cancel")
        let selection = choice.runModal()
        if selection == .alertThirdButtonReturn { return }
        screenControlEnabled = (selection == .alertSecondButtonReturn)
        if screenControlEnabled && controlPermission == "Off" {
            let notice = NSAlert()
            notice.messageText = "Screen Control Is Off"
            notice.informativeText = "Select Automatic or Ask Before Acting in Settings to use View & Control Screen."
            notice.runModal()
            return
        }
        if screenControlEnabled && !AXIsProcessTrusted() {
            let warning = NSAlert()
            warning.messageText = "Accessibility Permission Required"
            warning.informativeText = "To allow approved clicks, enable AVERA under System Settings → Privacy & Security → Accessibility, then try again."
            warning.runModal()
            return
        }
        guard CGPreflightScreenCaptureAccess() || CGRequestScreenCaptureAccess() else {
            let alert = NSAlert()
            alert.messageText = "Allow Screen Recording"
            alert.informativeText = "In System Settings → Privacy & Security → Screen Recording, allow AVERA. You may need to restart AVERA."
            alert.runModal()
            return
        }
        screenActive = true
        screenToggleButton?.title = "■   Stop Screen Analysis"
        screenInsightLabel?.stringValue = screenControlEnabled ? "LIVE  ·  View & Control" : "LIVE  ·  View Only"
        refreshFloatingPanel()
        analyzeScreenTick()
        screenTimer = Timer.scheduledTimer(withTimeInterval: 60, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in self?.analyzeScreenTick() }
        }
        let floatingChoice = NSAlert()
        floatingChoice.messageText = "Use a Small Floating Window?"
        floatingChoice.informativeText = "Keep AVERA in a compact window above other apps while screen analysis runs? You can return to the main window anytime."
        floatingChoice.addButton(withTitle: "Use Small Window")
        floatingChoice.addButton(withTitle: "Keep Main Window")
        if floatingChoice.runModal() == .alertFirstButtonReturn {
            showFloatingPanel()
        }
    }

    private func stopScreenAnalysis() {
        screenTimer?.invalidate()
        screenTimer = nil
        screenActive = false
        latestScreenJPEG = nil
        screenControlEnabled = false
        screenToggleButton?.title = "◉   Start Screen Analysis"
        screenInsightLabel?.stringValue = "OFF  ·  Screen not captured"
        refreshFloatingPanel()
    }

    private func captureScreenJPEG() -> Data? {
        guard let cgImage = CGDisplayCreateImage(CGMainDisplayID()) else { return nil }
        let bitmap = NSBitmapImageRep(cgImage: cgImage)
        return bitmap.representation(using: .jpeg, properties: [.compressionFactor: 0.85])
    }

    // Ollama runs locally at 127.0.0.1. No screenshot is sent to a cloud API.
    private func ollamaReply(_ chat: [[String: Any]], maxTokens: Int) async throws -> String {
        let url = URL(string: "http://127.0.0.1:11434/api/chat")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.timeoutInterval = 180
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "model": modelName, "messages": chat, "stream": false,
            "keep_alive": "15m", "options": ["num_predict": maxTokens, "temperature": responseMode == "Smart" ? 0.2 : 0.35, "num_ctx": 4096]
        ] as [String: Any])
        let (data, response) = try await URLSession.shared.data(for: request)
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
        if !(200...299).contains(status) {
            let reason = json?["error"] as? String ?? "HTTP \(status)"
            throw NSError(domain: "AVERA.Ollama", code: status, userInfo: [NSLocalizedDescriptionKey: reason])
        }
        let message = json?["message"] as? [String: Any]
        let answer = (message?["content"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if answer.isEmpty { throw NSError(domain: "AVERA.Ollama", code: -1, userInfo: [NSLocalizedDescriptionKey: "Ollama returned an empty response."]) }
        return answer
    }

    private func analyzeScreenTick() {
        guard screenActive, !screenBusy, !busy else { return }
        guard let jpeg = captureScreenJPEG() else {
            screenInsightLabel?.stringValue = "Screen capture unavailable"
            return
        }
        latestScreenJPEG = jpeg
        screenBusy = true
        screenInsightLabel?.stringValue = "LIVE  ·  Analyzing locally…"
        Task { [weak self] in
            guard let self else { return }
            defer { self.screenBusy = false }
            do {
                let answer = try await self.ollamaReply([[
                    "role": "user",
                    "content": "Describe the visible screen briefly in one sentence. Avoid copying personal or sensitive text.",
                    "images": [jpeg.base64EncodedString()]
                ]], maxTokens: 90)
                guard self.screenActive else { return }
                self.screenInsightLabel?.toolTip = answer
                self.screenInsightLabel?.stringValue = "LIVE  ·  " + String(answer.prefix(35))
            } catch {
                if self.screenActive { self.screenInsightLabel?.stringValue = "LIVE  ·  Ollama error (see tooltip)"; self.screenInsightLabel?.toolTip = error.localizedDescription }
            }
        }
    }

    private func sendRequest() {
        var chat: [[String: Any]] = [["role": "system", "content":
            "You are AVERA, a helpful macOS AI assistant. Be clear and concise. Never claim you opened an app, searched, clicked, typed, or changed anything unless the AVERA app confirms the action succeeded. If a user requests a computer action you cannot execute, explain that honestly. Saved user memory (may be outdated):\n" + self.memoryContext()]]
        for message in messages {
            chat.append(["role": message["role"] == "assistant" ? "assistant" : "user",
                         "content": message["content"] ?? ""])
        }
        if screenActive, let jpeg = latestScreenJPEG, !chat.isEmpty {
            chat[chat.count - 1]["images"] = [jpeg.base64EncodedString()]
        }
        let userRequest = messages.last?["content"] ?? ""
        if screenActive && screenControlEnabled && handleDirectComputerCommand(userRequest) {
            return
        }
        if screenActive && screenControlEnabled &&
           ["click", "select", "choose", "press", "tap"].contains(where: { userRequest.lowercased().contains($0) }) {
            suggestScreenAction(for: userRequest)
            return
        }
        if screenActive && isScreenQuestionRequest(userRequest) {
            answerVisibleQuestion(userRequest)
            return
        }
        Task { [weak self] in
            guard let self else { return }
            do {
                let tokenLimit = self.responseMode == "Fast" ? 180 : (self.responseMode == "Smart" ? 750 : 420)
                let answer = try await self.ollamaReply(chat, maxTokens: tokenLimit)
                self.finish(answer, nil)
            } catch {
                self.finish(nil, "Ollama connection failed: \(error.localizedDescription). Make sure Ollama is running and gemma3:4b is downloaded.")
            }
        }
    }

    // Question Mode always captures a FRESH screenshot. Do not answer from the
    // 15-second-old background screenshot or from imagined answer choices.
    private func isScreenQuestionRequest(_ request: String) -> Bool {
        let q = request.lowercased()
        return ["answer", "question", "multiple choice", "which option", "which choice", "correct choice", "correct option", "what's the answer", "what is the answer", "pick the", "choose the"].contains(where: { q.contains($0) })
    }

    private func answerVisibleQuestion(_ request: String) {
        guard let jpeg = captureScreenJPEG() else {
            finish(nil, "Couldn't capture the screen. Check Screen Recording permission.")
            return
        }
        Task { [weak self] in
            guard let self else { return }
            do {
                let prompt = """
                Read the CURRENT screenshot. The user asks: \(request)
                Extract the visible multiple-choice question and ALL visible answer options exactly.
                Reply ONLY as JSON with fields: question (string), options (array of objects with label and text strings), chosenLabel (string), explanation (short string), confidence (high/medium/low).
                The chosenLabel MUST exactly match one of the extracted option labels. If the question or any necessary choices are unreadable, use chosenLabel as an empty string and confidence low. Never invent an option. Do not click anything.
                """
                let raw = try await self.ollamaReply([["role": "user", "content": prompt, "images": [jpeg.base64EncodedString()]]], maxTokens: 450)
                let clean = raw.replacingOccurrences(of: "```json", with: "").replacingOccurrences(of: "```", with: "")
                guard let first = clean.firstIndex(of: "{"), let last = clean.lastIndex(of: "}"),
                      let data = String(clean[first...last]).data(using: .utf8),
                      let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let options = obj["options"] as? [[String: Any]], options.count >= 2,
                      let chosen = obj["chosenLabel"] as? String,
                      let selected = options.first(where: { ($0["label"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == chosen.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }),
                      let text = selected["text"] as? String, !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
                      (obj["confidence"] as? String ?? "low").lowercased() != "low" else {
                    self.finish("I can't reliably match an answer to the choices on your screen. Please zoom in or paste the question and options. I didn't click anything.", nil)
                    return
                }
                let label = selected["label"] as? String ?? chosen
                let explanation = obj["explanation"] as? String ?? ""
                self.finish("Based on the visible options: \(label). \(text)\n\n\(explanation)\n\nI did not click an answer. Please verify it before submitting.", nil)
            } catch {
                self.finish(nil, "Couldn't read the visible question: \(error.localizedDescription)")
            }
        }
    }

    // Deterministic, permission-gated actions. Never let a model response execute
    // shell commands, AppleScript, URLs, or keystrokes without explicit approval.
    private func handleDirectComputerCommand(_ request: String) -> Bool {
        let lower = request.lowercased()
        // Opening Chrome with a Google search is more reliable than guessed screen clicks.
        if lower.contains("chrome") && (lower.contains("search") || lower.contains("youtube")) {
            let query: String
            if let range = lower.range(of: "search for ") {
                query = String(request[range.upperBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
            } else if lower.contains("youtube") {
                query = "YouTube"
            } else {
                return false
            }
            guard !query.isEmpty, query.count < 250,
                  let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
                  let url = URL(string: "https://www.google.com/search?q=\(encoded)") else { return false }
            if controlPermission != "Automatic" {
                let alert = NSAlert()
                alert.messageText = "Allow AVERA to open Chrome?"
                alert.informativeText = "Search Google for: \(query)"
                alert.addButton(withTitle: "Open Search")
                alert.addButton(withTitle: "Cancel")
                guard alert.runModal() == .alertFirstButtonReturn else {
                    finish("Canceled. Chrome was not opened.", nil)
                    return true
                }
            }
            guard screenActive && screenControlEnabled else { return true }
            let chromeURL = URL(fileURLWithPath: "/Applications/Google Chrome.app")
            let configuration = NSWorkspace.OpenConfiguration()
            NSWorkspace.shared.open([url], withApplicationAt: chromeURL, configuration: configuration) { [weak self] _, error in
                DispatchQueue.main.async {
                    if let error = error {
                        self?.finish(nil, "Chrome could not open the search: \(error.localizedDescription)")
                    } else {
                        self?.finish("Opened a Google search for “\(query)” in Chrome.", nil)
                    }
                }
            }
            return true
        }
        // Type only literal text requested by the user, never text invented by a model.
        if lower.hasPrefix("type ") || lower.hasPrefix("write ") {
            let content = String(request.dropFirst(lower.hasPrefix("type ") ? 5 : 6))
            guard !content.isEmpty, content.utf16.count <= 500 else {
                finish("Please provide 1–500 characters to type.", nil)
                return true
            }
            guard AXIsProcessTrusted() else {
                finish("Accessibility permission is required before AVERA can type.", nil)
                return true
            }
            if controlPermission != "Automatic" {
                let alert = NSAlert()
                alert.messageText = "Approve typing into the active app?"
                alert.informativeText = "Type the exact text you requested: \(content)"
                alert.addButton(withTitle: "Type Text")
                alert.addButton(withTitle: "Cancel")
                guard alert.runModal() == .alertFirstButtonReturn else {
                    finish("Canceled. Nothing was typed.", nil)
                    return true
                }
            }
            guard screenActive && screenControlEnabled else { return true }
            // Hide AVERA so the target app can receive keyboard events.
            NSApp.hide(nil)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { [weak self] in
                for codeUnit in content.utf16 {
                    var character = codeUnit
                    guard let down = CGEvent(keyboardEventSource: nil, virtualKey: 0, keyDown: true),
                          let up = CGEvent(keyboardEventSource: nil, virtualKey: 0, keyDown: false) else {
                        self?.finish(nil, "Could not create keyboard events.")
                        return
                    }
                    withUnsafePointer(to: &character) { ptr in
                        down.keyboardSetUnicodeString(stringLength: 1, unicodeString: ptr)
                        up.keyboardSetUnicodeString(stringLength: 1, unicodeString: ptr)
                    }
                    down.post(tap: .cghidEventTap)
                    up.post(tap: .cghidEventTap)
                }
                self?.finish("Sent the approved text as keyboard events. Please check the target field.", nil)
            }
            return true
        }
        return false
    }

    // Click requests are never executed based solely on a model response.
    // The model returns a proposed coordinate and a description for human review.
    private func suggestScreenAction(for requestText: String) {
        guard let screenshot = captureScreenJPEG(),
              let cgImage = CGDisplayCreateImage(CGMainDisplayID()) else {
            finish(nil, "Unable to capture the screen for an action.")
            return
        }
        let width = cgImage.width
        let height = cgImage.height
        Task { [weak self] in
            guard let self else { return }
            do {
                let prompt = "You are identifying a proposed click, NOT performing it. The screenshot is \(width)x\(height) pixels. User request: \(requestText). Return ONLY JSON with keys x (integer pixel coordinate), y (integer pixel coordinate), reason (short description). If unclear, return {\"x\":-1,\"y\":-1,\"reason\":\"Cannot locate target\"}. Do not click submit, purchase, send, delete or confirm buttons."
                let raw = try await self.ollamaReply([["role": "user", "content": prompt, "images": [screenshot.base64EncodedString()]]], maxTokens: 160)
                let cleaned = raw.replacingOccurrences(of: "```json", with: "").replacingOccurrences(of: "```", with: "")
                guard let start = cleaned.firstIndex(of: "{"), let end = cleaned.lastIndex(of: "}"),
                      let data = String(cleaned[start...end]).data(using: .utf8),
                      let result = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let x = result["x"] as? Int, let y = result["y"] as? Int,
                      x >= 0, y >= 0, x < width, y < height else {
                    self.finish("I couldn't confidently locate the target. Try describing it more clearly.", nil)
                    return
                }
                let reason = result["reason"] as? String ?? "Proposed click"
                let lower = reason.lowercased()
                if ["submit", "purchase", "buy", "send", "delete", "confirm", "pay"].contains(where: { lower.contains($0) }) {
                    self.finish("I won't click a potentially consequential button automatically. Please do that yourself.", nil)
                    return
                }
                // Never automate potentially consequential clicks, including when
                // the user request itself mentions a sensitive action.
                let requestLower = requestText.lowercased()
                let sensitive = ["submit", "purchase", "buy", "send", "delete", "confirm", "pay", "checkout", "transfer", "password", "sign in", "log in", "agree", "accept", "post", "publish", "install", "download", "authorize"]
                if sensitive.contains(where: { requestLower.contains($0) || lower.contains($0) }) {
                    self.finish("This action needs manual confirmation. I didn't click anything.", nil)
                    return
                }
                // Convert Retina screenshot pixels to Quartz screen points, then
                // validate the underlying Accessibility element before clicking.
                let bounds = CGDisplayBounds(CGMainDisplayID())
                let point = CGPoint(x: bounds.minX + CGFloat(x) * bounds.width / CGFloat(width),
                                    y: bounds.minY + CGFloat(y) * bounds.height / CGFloat(height))
                guard AXIsProcessTrusted() else {
                    self.finish("Enable AVERA in macOS Accessibility settings to allow clicks.", nil)
                    return
                }
                var element: AXUIElement?
                let system = AXUIElementCreateSystemWide()
                let axStatus = AXUIElementCopyElementAtPosition(system, Float(point.x), Float(point.y), &element)
                guard axStatus == .success, let element else {
                    self.finish("I couldn't verify a clickable control at that position. I didn't click.", nil)
                    return
                }
                var roleValue: CFTypeRef?
                AXUIElementCopyAttributeValue(element, kAXRoleAttribute as CFString, &roleValue)
                let role = (roleValue as? String) ?? ""
                let allowedRoles = ["AXButton", "AXRadioButton", "AXCheckBox", "AXLink", "AXMenuItem"]
                guard allowedRoles.contains(role) else {
                    self.finish("I located \(reason), but it isn't a verified clickable button or link. I didn't click.", nil)
                    return
                }
                var titleValue: CFTypeRef?
                AXUIElementCopyAttributeValue(element, kAXTitleAttribute as CFString, &titleValue)
                let title = ((titleValue as? String) ?? "").lowercased()
                let reasonWords = reason.lowercased().split(whereSeparator: { !$0.isLetter && !$0.isNumber })
                    .map(String.init).filter { $0.count >= 4 && !["click", "button", "target", "option", "possible", "screen"].contains($0) }
                guard !title.isEmpty, reasonWords.contains(where: { title.contains($0) }) else {
                    self.finish("I found a control, but its label doesn't match the requested target. I didn't click the wrong item.", nil)
                    return
                }
                let dangerous = ["submit", "purchase", "buy", "send", "delete", "confirm", "pay", "checkout", "transfer", "password", "sign in", "log in", "agree", "accept", "post", "publish", "install", "authorize"]
                guard !dangerous.contains(where: { title.contains($0) }) else {
                    self.finish("That control needs manual confirmation. I didn't click.", nil)
                    return
                }
                if self.controlPermission != "Automatic" {
                    let alert = NSAlert()
                    alert.messageText = "Click this verified control?"
                    alert.informativeText = title.isEmpty ? reason : title
                    alert.addButton(withTitle: "Click")
                    alert.addButton(withTitle: "Cancel")
                    guard alert.runModal() == .alertFirstButtonReturn else {
                        self.finish("Canceled the click.", nil)
                        return
                    }
                }
                let status = AXUIElementPerformAction(element, kAXPressAction as CFString)
                if status == .success {
                    self.finish("Clicked the verified \(role) control: \(title.isEmpty ? reason : title).", nil)
                } else {
                    self.finish("The control didn't accept an Accessibility click. I didn't send an unverified mouse click.", nil)
                }
                return
            } catch { self.finish(nil, "Screen action suggestion failed: \(error.localizedDescription)") }
        }
    }

    private func receiveStreamingChunk(_ chunk: String) {
        streamingText += chunk
        thinkingLabel.stringValue = "✦  AVERA is responding…"
        renderMessages()
        if !streamingText.isEmpty {
            chatView.scrollToEndOfDocument(nil)
        }
    }

    private func finish(_ answer: String?, _ error: String?) {
        if let answer = answer, !answer.isEmpty {
            messages.append(["role": "assistant", "content": answer])
            streamingText = ""
            saveCurrentChat()
            renderMessages()
            animateLatestMessage()
        } else {
            streamingText = ""
            renderMessages()
            append("AVERA\nError: \(error ?? "Unknown error")\n\n")
        }
        busy = false
        stopThinkingAnimation()
        sendButton.isEnabled = true
        window.makeFirstResponder(input)
    }

    private func animateLatestMessage() {
        chatView.alphaValue = 0.65
        let rise = CABasicAnimation(keyPath: "transform.translation.y")
        rise.fromValue = -10
        rise.toValue = 0
        rise.duration = 0.38
        rise.timingFunction = CAMediaTimingFunction(name: .easeOut)
        chatView.layer?.add(rise, forKey: "assistantMessageRise")
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.38
            chatView.animator().alphaValue = 1
        }
    }

    private func startThinkingAnimation() {
        star.setThinking(true)
        thinkingStep = 0
        thinkingLabel.stringValue = "✦  AVERA is thinking"
        thinkingTimer?.invalidate()
        thinkingTimer = Timer.scheduledTimer(withTimeInterval: 0.42, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self else { return }
                self.thinkingStep = (self.thinkingStep + 1) % 4
                self.thinkingLabel.stringValue = "✦  AVERA is thinking" + String(repeating: " •", count: self.thinkingStep)
                let flicker = CABasicAnimation(keyPath: "opacity")
                flicker.fromValue = 0.45
                flicker.toValue = 1
                flicker.duration = 0.32
                self.thinkingLabel.layer?.add(flicker, forKey: "thinkingFlicker")
            }
        }
    }

    private func stopThinkingAnimation() {
        thinkingTimer?.invalidate()
        thinkingTimer = nil
        thinkingLabel.stringValue = ""
        star.setThinking(false)
    }

    private func loadChats() {
        guard let data = try? Data(contentsOf: storageURL),
              let saved = try? JSONDecoder().decode([SavedChat].self, from: data) else { return }
        chats = saved.sorted { $0.updated > $1.updated }
    }

    private func saveCurrentChat() {
        guard !messages.isEmpty else { return }
        let first = messages.first(where: { $0["role"] == "user" })?["content"] ?? "New chat"
        let title = String(first.prefix(45)).replacingOccurrences(of: "\n", with: " ")
        let record = SavedChat(id: currentID, title: title, updated: Date(), messages: messages)
        if let index = chats.firstIndex(where: { $0.id == currentID }) {
            chats[index] = record
        } else {
            chats.append(record)
        }
        chats.sort { $0.updated > $1.updated }
        persistChats()
    }

    private func persistChats() {
        do {
            try FileManager.default.createDirectory(at: storageURL.deletingLastPathComponent(),
                                                    withIntermediateDirectories: true)
            let data = try JSONEncoder().encode(chats)
            try data.write(to: storageURL, options: .atomic)
        } catch {
            NSLog("AVERA could not save chats: %@", error.localizedDescription)
        }
    }

    private func renderMessages() {
        let output = NSMutableAttributedString()
        let base = NSFont.systemFont(ofSize: 15)
        let muted = NSColor.white.withAlphaComponent(0.72)
        func add(_ text: String, font: NSFont = .systemFont(ofSize: 15), color: NSColor = .white) {
            output.append(NSAttributedString(string: text, attributes: [.font: font, .foregroundColor: color]))
        }
        add("AVERA\n", font: .systemFont(ofSize: 16, weight: .semibold))
        add("\nHow can I help you today?\n\n", color: muted)
        for message in messages {
            let isAssistant = message["role"] == "assistant"
            add(isAssistant ? "AVERA\n" : "YOU\n", font: .systemFont(ofSize: 12, weight: .semibold), color: isAssistant ? .white : NSColor.white.withAlphaComponent(0.66))
            appendMarkdown(message["content"] ?? "", to: output, baseFont: base)
            add("\n\n")
        }
        if !streamingText.isEmpty {
            add("AVERA\n", font: .systemFont(ofSize: 12, weight: .semibold), color: .white)
            appendMarkdown(streamingText, to: output, baseFont: base)
        }
        chatView.textStorage?.setAttributedString(output)
        chatView.scrollToEndOfDocument(nil)
        refreshFloatingPanel()
    }

    private func appendMarkdown(_ text: String, to output: NSMutableAttributedString, baseFont: NSFont) {
        let lines = text.components(separatedBy: .newlines)
        let paragraph = NSMutableParagraphStyle()
        paragraph.lineSpacing = 3
        paragraph.paragraphSpacing = 5
        for line in lines {
            var content = line
            var font = baseFont
            if content.hasPrefix("### ") {
                content = String(content.dropFirst(4)); font = .systemFont(ofSize: 16, weight: .semibold)
            } else if content.hasPrefix("## ") {
                content = String(content.dropFirst(3)); font = .systemFont(ofSize: 18, weight: .semibold)
            } else if content.hasPrefix("# ") {
                content = String(content.dropFirst(2)); font = .systemFont(ofSize: 21, weight: .bold)
            } else if content.hasPrefix("- ") || content.hasPrefix("* ") {
                content = "•  " + String(content.dropFirst(2))
            } else if content.hasPrefix("> ") {
                content = "│  " + String(content.dropFirst(2))
            }
            let attrs: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: NSColor.white, .paragraphStyle: paragraph]
            let lineText = NSMutableAttributedString(string: content + "\n", attributes: attrs)
            let full = NSRange(location: 0, length: lineText.length)
            if let boldRegex = try? NSRegularExpression(pattern: #"\*\*(.+?)\*\*"#) {
                for match in boldRegex.matches(in: lineText.string, range: full).reversed() {
                    guard let inner = Range(match.range(at: 1), in: lineText.string) else { continue }
                    let value = String(lineText.string[inner])
                    lineText.replaceCharacters(in: match.range, with: value)
                    let range = NSRange(location: match.range.location, length: (value as NSString).length)
                    lineText.addAttribute(.font, value: NSFont.systemFont(ofSize: font.pointSize, weight: .bold), range: range)
                }
            }
            if let codeRegex = try? NSRegularExpression(pattern: #"`([^`]+)`"#) {
                for match in codeRegex.matches(in: lineText.string, range: NSRange(location: 0, length: lineText.length)).reversed() {
                    guard let inner = Range(match.range(at: 1), in: lineText.string) else { continue }
                    let value = String(lineText.string[inner])
                    lineText.replaceCharacters(in: match.range, with: value)
                    let range = NSRange(location: match.range.location, length: (value as NSString).length)
                    lineText.addAttributes([.font: NSFont.monospacedSystemFont(ofSize: font.pointSize - 1, weight: .regular), .foregroundColor: NSColor(calibratedRed: 0.82, green: 0.88, blue: 1, alpha: 1)], range: range)
                }
            }
            output.append(lineText)
        }
    }

    private func showMemory() {
        closeHistory()
        closeSettingsAction()
        memoryPanel?.removeFromSuperview()
        let panel = glass(NSRect(x: 263, y: 14, width: root.bounds.width - 277, height: root.bounds.height - 28), material: .hudWindow)
        panel.autoresizingMask = [.width, .height]
        root.addSubview(panel)
        memoryPanel = panel
        let title = label("AVERA Memory", size: 28, weight: .semibold)
        title.frame = NSRect(x: 32, y: panel.bounds.height - 76, width: 500, height: 40)
        title.autoresizingMask = [.minYMargin]
        panel.addSubview(title)
        let subtitle = label("Saved locally on this Mac. Start a message with ‘Remember that…’ to save a fact.", size: 12, color: .white.withAlphaComponent(0.65))
        subtitle.frame = NSRect(x: 34, y: panel.bounds.height - 108, width: panel.bounds.width - 68, height: 24)
        subtitle.autoresizingMask = [.width, .minYMargin]
        panel.addSubview(subtitle)
        let field = NSTextField(frame: NSRect(x: 34, y: panel.bounds.height - 164, width: panel.bounds.width - 190, height: 34))
        field.placeholderString = "Add a memory..."
        field.textColor = .white
        field.backgroundColor = NSColor.white.withAlphaComponent(0.06)
        field.isBezeled = false
        field.wantsLayer = true
        field.layer?.cornerRadius = 8
        field.autoresizingMask = [.width, .minYMargin]
        panel.addSubview(field)
        memoryInput = field
        let add = button("Save Memory", frame: NSRect(x: panel.bounds.width - 145, y: panel.bounds.height - 164, width: 110, height: 34), action: #selector(addMemoryAction))
        add.autoresizingMask = [.minXMargin, .minYMargin]
        panel.addSubview(add)
        let list = memories.isEmpty ? "No memories saved yet." : memories.enumerated().map { "\($0.offset + 1).  \($0.element)" }.joined(separator: "\n\n")
        let textView = NSTextView(frame: NSRect(x: 34, y: 92, width: panel.bounds.width - 68, height: panel.bounds.height - 285))
        textView.string = list
        textView.isEditable = false
        textView.drawsBackground = false
        textView.textColor = NSColor.white.withAlphaComponent(0.9)
        textView.font = .systemFont(ofSize: 14)
        textView.autoresizingMask = [.width, .height]
        let scroll = NSScrollView(frame: textView.frame)
        scroll.documentView = textView
        scroll.hasVerticalScroller = true
        scroll.drawsBackground = false
        scroll.autoresizingMask = [.width, .height]
        panel.addSubview(scroll)
        let clear = button("Clear All Memories", frame: NSRect(x: 34, y: 28, width: 160, height: 38), action: #selector(clearMemoriesAction))
        clear.autoresizingMask = [.maxYMargin]
        panel.addSubview(clear)
        let done = button("Done", frame: NSRect(x: panel.bounds.width - 110, y: 28, width: 76, height: 38), action: #selector(closeMemoryAction))
        done.autoresizingMask = [.minXMargin, .maxYMargin]
        panel.addSubview(done)
    }

    @objc private func addMemoryAction() {
        let fact = memoryInput?.stringValue.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !fact.isEmpty else { return }
        memories.append(String(fact.prefix(300)))
        memories = Array(memories.suffix(100))
        persistMemories()
        showMemory()
    }

    @objc private func clearMemoriesAction() {
        let alert = NSAlert()
        alert.messageText = "Clear saved memories?"
        alert.informativeText = "This permanently removes AVERA's saved personal memory on this Mac."
        alert.addButton(withTitle: "Clear")
        alert.addButton(withTitle: "Cancel")
        if alert.runModal() == .alertFirstButtonReturn { memories.removeAll(); persistMemories(); showMemory() }
    }

    @objc private func closeMemoryAction() { memoryPanel?.removeFromSuperview(); memoryPanel = nil }

    private func updateScriptURL() -> URL? {
        guard let resources = Bundle.main.resourceURL else { return nil }
        let script = resources.appendingPathComponent("avera_updater.py")
        return FileManager.default.fileExists(atPath: script.path) ? script : nil
    }

    private func updateStatusText(_ text: String, showAlert: Bool = false) {
        updateStatusLabel?.stringValue = text
        if showAlert {
            let alert = NSAlert()
            alert.messageText = "AVERA Updates"
            alert.informativeText = text
            alert.runModal()
        }
    }

    @objc private func checkUpdatesAction() { checkForUpdates(silent: false) }

    private func checkForUpdates(silent: Bool) {
        guard let script = updateScriptURL() else {
            if !silent { updateStatusText("Updater not installed. Reinstall AVERA from the new ZIP.", showAlert: true) }
            return
        }
        if !silent { updateStatusText("Checking GitHub Releases…") }
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let task = Process()
            task.executableURL = URL(fileURLWithPath: "/usr/bin/python3")
            task.arguments = [script.path, "check", "--current", "1.2.0"]
            let out = Pipe()
            task.standardOutput = out
            task.standardError = Pipe()
            do {
                try task.run()
                let data = out.fileHandleForReading.readDataToEndOfFile()
                task.waitUntilExit()
                let response = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
                let available = response["available"] as? Bool ?? false
                let message = response["message"] as? String ?? "Could not check GitHub releases."
                DispatchQueue.main.async { [weak self] in
                    guard let self else { return }
                    if task.terminationStatus != 0 { if !silent { self.updateStatusText(message, showAlert: true) }; return }
                    if available {
                        self.updateStatusText("Update found. Downloading…")
                        self.downloadUpdate(script: script, release: response, silent: silent)
                    } else if !silent { self.updateStatusText(message, showAlert: true) }
                }
            } catch {
                DispatchQueue.main.async { [weak self] in if !silent { self?.updateStatusText("Update check failed: \(error.localizedDescription)", showAlert: true) } }
            }
        }
    }

    private func downloadUpdate(script: URL, release: [String: Any], silent: Bool) {
        guard let url = release["asset_url"] as? String,
              let checksum = release["sha256_url"] as? String else { return }
        DispatchQueue.global(qos: .utility).async { [weak self] in
            let task = Process()
            task.executableURL = URL(fileURLWithPath: "/usr/bin/python3")
            task.arguments = [script.path, "download", "--asset", url, "--sha256", checksum]
            let out = Pipe()
            task.standardOutput = out
            task.standardError = Pipe()
            do {
                try task.run()
                let data = out.fileHandleForReading.readDataToEndOfFile()
                task.waitUntilExit()
                let response = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
                let ok = task.terminationStatus == 0 && (response["ok"] as? Bool ?? false)
                let message = response["message"] as? String ?? "Update download failed."
                DispatchQueue.main.async { [weak self] in
                    guard let self else { return }
                    if ok { self.stagedUpdate = true; self.updateStatusText("Update ready — quit AVERA to install") }
                    else if !silent { self.updateStatusText(message, showAlert: true) }
                }
            } catch {
                DispatchQueue.main.async { [weak self] in if !silent { self?.updateStatusText("Update failed: \(error.localizedDescription)", showAlert: true) } }
            }
        }
    }

    private func installStagedUpdateAfterQuit() {
        guard let script = updateScriptURL() else { return }
        let task = Process()
        task.executableURL = URL(fileURLWithPath: "/usr/bin/python3")
        task.arguments = [script.path, "install-on-exit", "--pid", String(ProcessInfo.processInfo.processIdentifier), "--app", Bundle.main.bundleURL.path]
        task.standardOutput = FileHandle.nullDevice
        task.standardError = FileHandle.nullDevice
        do { try task.run() } catch { NSLog("AVERA updater launch failed: \(error)") }
    }

    private func showSettings() {
        closeHistory()
        memoryPanel?.removeFromSuperview()
        memoryPanel = nil
        settingsPanel?.removeFromSuperview()
        let panel = glass(NSRect(x: 263, y: 14, width: root.bounds.width - 277,
                                 height: root.bounds.height - 28), material: .hudWindow)
        panel.autoresizingMask = [.width, .height]
        panel.alphaValue = 0
        root.addSubview(panel)
        settingsPanel = panel
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.24
            panel.animator().alphaValue = 1
        }

        let title = label("Settings", size: 28, weight: .semibold)
        title.frame = NSRect(x: 32, y: panel.bounds.height - 76, width: 500, height: 40)
        title.autoresizingMask = [.minYMargin]
        panel.addSubview(title)
        let description = label("Local AI with Ollama. No API key or usage billing required.", size: 13,
                                color: .white.withAlphaComponent(0.68))
        description.frame = NSRect(x: 34, y: panel.bounds.height - 108, width: 600, height: 24)
        description.autoresizingMask = [.minYMargin]
        panel.addSubview(description)

        let modelLabel = label("MODEL", size: 11, weight: .semibold, color: .white.withAlphaComponent(0.58))
        modelLabel.frame = NSRect(x: 34, y: panel.bounds.height - 165, width: 120, height: 18)
        modelLabel.autoresizingMask = [.minYMargin]
        panel.addSubview(modelLabel)
        let popup = NSPopUpButton(frame: NSRect(x: 34, y: panel.bounds.height - 202, width: 330, height: 30), pullsDown: false)
        popup.addItems(withTitles: ["gemma3:4b"])
        popup.selectItem(withTitle: modelName)
        popup.autoresizingMask = [.minYMargin]
        panel.addSubview(popup)
        settingsModelPopup = popup

        let modeTitle = label("RESPONSE MODE", size: 11, weight: .semibold, color: .white.withAlphaComponent(0.58))
        modeTitle.frame = NSRect(x: 34, y: panel.bounds.height - 254, width: 240, height: 20)
        modeTitle.autoresizingMask = [.minYMargin]
        panel.addSubview(modeTitle)
        let modePopup = NSPopUpButton(frame: NSRect(x: 34, y: panel.bounds.height - 291, width: 330, height: 30), pullsDown: false)
        modePopup.addItems(withTitles: ["Fast", "Balanced", "Smart"])
        modePopup.selectItem(withTitle: responseMode)
        modePopup.autoresizingMask = [.minYMargin]
        panel.addSubview(modePopup)
        responseModePopup = modePopup

        let controlTitle = label("SCREEN CONTROL PERMISSION", size: 11, weight: .semibold, color: .white.withAlphaComponent(0.58))
        controlTitle.frame = NSRect(x: 34, y: panel.bounds.height - 345, width: 330, height: 20)
        controlTitle.autoresizingMask = [.minYMargin]
        panel.addSubview(controlTitle)
        let controlPopup = NSPopUpButton(frame: NSRect(x: 34, y: panel.bounds.height - 382, width: 330, height: 30), pullsDown: false)
        controlPopup.addItems(withTitles: ["Off", "Ask Before Acting", "Automatic"])
        controlPopup.selectItem(withTitle: controlPermission)
        controlPopup.autoresizingMask = [.minYMargin]
        panel.addSubview(controlPopup)
        controlPermissionPopup = controlPopup
        let controlInfo = label("Automatic runs low-risk actions; sensitive actions remain blocked.", size: 11, color: .white.withAlphaComponent(0.58))
        controlInfo.frame = NSRect(x: 34, y: panel.bounds.height - 411, width: 550, height: 20)
        controlInfo.autoresizingMask = [.minYMargin]
        panel.addSubview(controlInfo)

        let discordTitle = label("DISCORD RICH PRESENCE", size: 11, weight: .semibold, color: .white.withAlphaComponent(0.58))
        discordTitle.frame = NSRect(x: 34, y: panel.bounds.height - 451, width: 300, height: 20)
        discordTitle.autoresizingMask = [.minYMargin]
        panel.addSubview(discordTitle)
        let toggle = NSButton(checkboxWithTitle: "Show AVERA activity on Discord", target: nil, action: nil)
        toggle.state = discordEnabled ? .on : .off
        toggle.frame = NSRect(x: 34, y: panel.bounds.height - 485, width: 350, height: 25)
        toggle.autoresizingMask = [.minYMargin]
        panel.addSubview(toggle)
        discordToggle = toggle
        let idField = NSTextField(frame: NSRect(x: 34, y: panel.bounds.height - 522, width: 330, height: 26))
        idField.placeholderString = "Discord application ID (required)"
        idField.stringValue = discordAppID
        idField.autoresizingMask = [.minYMargin]
        panel.addSubview(idField)
        discordAppIDField = idField
        let localInfo = label("Discord desktop must be open. Get an App ID in Discord Developer Portal.", size: 11,
                              color: .white.withAlphaComponent(0.62))
        localInfo.frame = NSRect(x: 34, y: panel.bounds.height - 547, width: 590, height: 22)
        localInfo.autoresizingMask = [.minYMargin]
        panel.addSubview(localInfo)

        let updatesTitle = label("GITHUB AUTOMATIC UPDATES", size: 11, weight: .semibold, color: .white.withAlphaComponent(0.58))
        updatesTitle.frame = NSRect(x: 385, y: panel.bounds.height - 165, width: 280, height: 20)
        updatesTitle.autoresizingMask = [.minYMargin]
        panel.addSubview(updatesTitle)
        let updates = NSButton(checkboxWithTitle: "Download updates automatically", target: nil, action: nil)
        updates.state = autoUpdates ? .on : .off
        updates.frame = NSRect(x: 385, y: panel.bounds.height - 205, width: 295, height: 26)
        updates.autoresizingMask = [.minYMargin]
        panel.addSubview(updates)
        updateToggle = updates
        let check = button("Check for Updates", frame: NSRect(x: 385, y: panel.bounds.height - 255, width: 185, height: 36), action: #selector(checkUpdatesAction))
        check.autoresizingMask = [.minYMargin]
        panel.addSubview(check)
        let updateInfo = label("Version \(appVersion) • github.com/AdvanceCheck/Avera2", size: 11, color: .white.withAlphaComponent(0.65))
        updateInfo.frame = NSRect(x: 385, y: panel.bounds.height - 288, width: 310, height: 22)
        updateInfo.autoresizingMask = [.minYMargin]
        panel.addSubview(updateInfo)
        let updateStatus = label(stagedUpdate ? "Update ready; installs when AVERA quits" : "Updates require a published GitHub Release", size: 11, color: .white.withAlphaComponent(0.7))
        updateStatus.frame = NSRect(x: 385, y: panel.bounds.height - 322, width: 310, height: 52)
        updateStatus.maximumNumberOfLines = 2
        updateStatus.autoresizingMask = [.minYMargin]
        panel.addSubview(updateStatus)
        updateStatusLabel = updateStatus

        let save = button("Save Settings", frame: NSRect(x: panel.bounds.width - 170, y: 28, width: 136, height: 40), action: #selector(saveSettingsAction))
        save.autoresizingMask = [.minXMargin, .maxYMargin]
        panel.addSubview(save)
        let done = button("Done", frame: NSRect(x: panel.bounds.width - 260, y: 28, width: 76, height: 40), action: #selector(closeSettingsAction))
        done.autoresizingMask = [.minXMargin, .maxYMargin]
        panel.addSubview(done)
    }

    @objc private func saveSettingsAction() {
        if let selected = settingsModelPopup?.titleOfSelectedItem, !selected.isEmpty {
            modelName = selected
        }
        if let chosen = responseModePopup?.titleOfSelectedItem {
            responseMode = chosen
            UserDefaults.standard.set(chosen, forKey: "avera.responseMode")
        }
        if let chosen = controlPermissionPopup?.titleOfSelectedItem {
            controlPermission = chosen
            UserDefaults.standard.set(chosen, forKey: "avera.controlPermission")
            if chosen == "Off" { screenControlEnabled = false }
        }
        autoUpdates = updateToggle?.state == .on
        UserDefaults.standard.set(autoUpdates, forKey: "avera.autoUpdates")
        if autoUpdates && !stagedUpdate { checkForUpdates(silent: true) }
        discordEnabled = discordToggle?.state == .on
        discordAppID = discordAppIDField?.stringValue.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        UserDefaults.standard.set(discordEnabled, forKey: "avera.discordEnabled")
        UserDefaults.standard.set(discordAppID, forKey: "avera.discordAppID")
        startDiscordRPCIfNeeded()
        updateStatus()
        closeSettingsAction()
    }

    @objc private func closeSettingsAction() {
        settingsPanel?.removeFromSuperview()
        settingsPanel = nil
        settingsKeyField = nil
        settingsModelPopup = nil
        responseModePopup = nil
        controlPermissionPopup = nil
        discordToggle = nil
        discordAppIDField = nil
        updateToggle = nil
        updateStatusLabel = nil
    }

    private func closeHistory() {
        historyPanel?.removeFromSuperview()
        historyPanel = nil
    }

    private func showHistory() {
        closeSettingsAction()
        memoryPanel?.removeFromSuperview()
        memoryPanel = nil
        saveCurrentChat()
        closeHistory()
        let panel = glass(NSRect(x: 263, y: 14, width: root.bounds.width - 277,
                                 height: root.bounds.height - 28), material: .hudWindow)
        panel.autoresizingMask = [.width, .height]
        panel.alphaValue = 0
        root.addSubview(panel)
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.22
            panel.animator().alphaValue = 1
        }
        historyPanel = panel
        let title = label("Conversation history", size: 27, weight: .semibold)
        title.frame = NSRect(x: 30, y: panel.bounds.height - 72, width: 440, height: 40)
        title.autoresizingMask = [.minYMargin]
        panel.addSubview(title)
        let close = button("Done", frame: NSRect(x: panel.bounds.width - 110,
                            y: panel.bounds.height - 70, width: 75, height: 36),
                           action: #selector(closeHistoryAction))
        close.autoresizingMask = [.minXMargin, .minYMargin]
        panel.addSubview(close)
        let search = NSSearchField(frame: NSRect(x: 30, y: panel.bounds.height - 120,
                                                width: panel.bounds.width - 60, height: 30))
        search.autoresizingMask = [.width, .minYMargin]
        search.placeholderString = "Search saved chats"
        search.target = self
        search.action = #selector(filterHistory)
        search.sendsSearchStringImmediately = true
        panel.addSubview(search)
        searchField = search
        refreshHistoryList()
    }

    @objc private func closeHistoryAction() { closeHistory() }
    @objc private func filterHistory() { refreshHistoryList() }

    private func refreshHistoryList() {
        guard let panel = historyPanel else { return }
        panel.subviews.filter { $0.identifier?.rawValue == "historyRow" }.forEach { $0.removeFromSuperview() }
        let query = searchField.stringValue.lowercased()
        let matches = chats.filter {
            query.isEmpty || $0.title.lowercased().contains(query) ||
            $0.messages.contains(where: { ($0["content"] ?? "").lowercased().contains(query) })
        }
        for (index, chat) in matches.prefix(9).enumerated() {
            let row = button(chat.title, frame: NSRect(x: 30,
                y: panel.bounds.height - 175 - CGFloat(index) * 51,
                width: panel.bounds.width - 60, height: 42),
                action: #selector(openHistoryRow(_:)), tag: index)
            row.identifier = NSUserInterfaceItemIdentifier("historyRow")
            row.autoresizingMask = [.width, .minYMargin]
            panel.addSubview(row)
        }
        displayedHistory = Array(matches.prefix(9))
    }

    private var displayedHistory: [SavedChat] = []

    @objc private func openHistoryRow(_ sender: NSButton) {
        guard displayedHistory.indices.contains(sender.tag), !busy else { return }
        let chat = displayedHistory[sender.tag]
        saveCurrentChat()
        currentID = chat.id
        messages = chat.messages
        renderMessages()
        closeHistory()
    }

    @objc private func copyConversation() {
        NSPasteboard.general.clearContents()
        NSPasteboard.general.setString(chatView.string, forType: .string)
    }

}

@main struct AVERAMain {
    @MainActor static func main() {
        let app = NSApplication.shared
        let controller = AVERAController()
        app.delegate = controller
        app.run()
    }
}
