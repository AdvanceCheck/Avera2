import Foundation
import CryptoKit

enum AVERALicenseVerifier {
    // Replaced at installation time with YOUR Ed25519 public key (never the private key).
    static let publicKeyBase64 = "__AVERA_PUBLIC_KEY_BASE64__"

    static func verify(_ token: String) -> String? {
        let parts = token.trimmingCharacters(in: .whitespacesAndNewlines).split(separator: ".", omittingEmptySubsequences: false)
        guard parts.count == 3, parts[0] == "AVERA1",
              let publicBytes = Data(base64Encoded: publicKeyBase64), publicBytes.count == 32,
              let claimsBytes = decodeURL(String(parts[1])),
              let signature = decodeURL(String(parts[2])), signature.count == 64,
              let publicKey = try? Curve25519.Signing.PublicKey(rawRepresentation: publicBytes),
              publicKey.isValidSignature(signature, for: claimsBytes),
              let claims = try? JSONSerialization.jsonObject(with: claimsBytes) as? [String: Any],
              claims["product"] as? String == "AVERA", claims["v"] as? Int == 1,
              let id = claims["license_id"] as? String, !id.isEmpty,
              let issued = claims["issued_at"] as? String,
              let issuedDate = ISO8601DateFormatter().date(from: issued),
              issuedDate <= Date().addingTimeInterval(300) else { return nil }
        if let expiry = claims["expires_at"] as? String {
            guard let date = ISO8601DateFormatter().date(from: expiry), date > Date() else { return nil }
        }
        return id
    }

    private static func decodeURL(_ string: String) -> Data? {
        let base = string.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        return Data(base64Encoded: base + String(repeating: "=", count: (4 - base.count % 4) % 4))
    }
}
